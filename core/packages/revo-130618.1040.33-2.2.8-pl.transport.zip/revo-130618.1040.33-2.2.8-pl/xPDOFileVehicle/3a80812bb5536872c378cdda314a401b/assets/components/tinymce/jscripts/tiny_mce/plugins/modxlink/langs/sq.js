tinyMCE.addI18n('sq.modxlink',{
    link_desc:"Insert/edit link"
});