<?php
/**
 * @package modx
 * @subpackage manager.controllers
 */
class StaticResourceDataManagerController extends ResourceDataManagerController {}
