<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '67611d99f427945954ccf9be4b530632',
      'native_key' => 'core',
      'filename' => 'modNamespace/047501fa904bf6dba2c7a8a1abd5a3d2.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modWorkspace',
      'guid' => '990d633352ee771ab3f0bb5e4aa29319',
      'native_key' => 1,
      'filename' => 'modWorkspace/c3e992188abd89e27d2eb558301d892a.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modTransportProvider',
      'guid' => 'bcd3fb72220d1fd215d61ed53ee2d6c2',
      'native_key' => 1,
      'filename' => 'modTransportProvider/c8203695b10d765d80ffd2e284d645fc.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '6bca7438d58d875f1d373ce7001b6caf',
      'native_key' => 1,
      'filename' => 'modAction/32d1d0a2972218feaa637d9f3dc70e15.vehicle',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '45217662b70b7b3d6cf5c24f59393a5c',
      'native_key' => 3,
      'filename' => 'modAction/e3b1b0955db2e0100341a437cbfd6364.vehicle',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '99272036d0c16cf8714f93c9849c56a6',
      'native_key' => 5,
      'filename' => 'modAction/d2c2bdcd64a1827088bb3b676748dd44.vehicle',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'a0d5d4775413127430729226f330ee81',
      'native_key' => 7,
      'filename' => 'modAction/fb8b717b2e94cad991051ddf9c3c1c30.vehicle',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '98b3960f28aa5b636ae45ad0eb4fceec',
      'native_key' => 8,
      'filename' => 'modAction/6b6e3e1c0259c64bbb39c97a392241ee.vehicle',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '1107a8cd2da501497f54480fea2bf0f9',
      'native_key' => 9,
      'filename' => 'modAction/15e69d2fecc4a3be3a04d1165f304393.vehicle',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '89d968ef8bdeedbf499f3376de92d7e7',
      'native_key' => 10,
      'filename' => 'modAction/98021775dec72cda12576da678197a85.vehicle',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '1da2f42285998c43e1eeffb3e99cbc09',
      'native_key' => 11,
      'filename' => 'modAction/0616390bba6eeae162f2d1aec074f6f5.vehicle',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '05c0c537b2cb1a9039e905f6158385e7',
      'native_key' => 12,
      'filename' => 'modAction/bf0af2eead9789fa6d2b163e0f7d7414.vehicle',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '736e7f0289c664f8fbd9581391177a1b',
      'native_key' => 13,
      'filename' => 'modAction/12c580ba0bf82c91ab37e5174109c2e9.vehicle',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '80b4068952abb1547e11969ccf479175',
      'native_key' => 20,
      'filename' => 'modAction/487a13c2f8eae8f8bd2e05aff59096c6.vehicle',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'd146c85180c753c61a1cf43e61b3b575',
      'native_key' => 21,
      'filename' => 'modAction/93dc565809f4cb09f814ea916f7c848f.vehicle',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'bb70e9db25e43c5a29c3fa37ad0b6782',
      'native_key' => 22,
      'filename' => 'modAction/3331f88a012c36180ae4cee853fa2e07.vehicle',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '5225be8d3d2ddf3070cbebf549d12487',
      'native_key' => 25,
      'filename' => 'modAction/f2fe9b7ee5b6e55792f99ebd133b4e75.vehicle',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '13e3b1d1bffb08b17a293ac5320bddeb',
      'native_key' => 26,
      'filename' => 'modAction/e0aeb0e5623c8ce42b994925fa0e800c.vehicle',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '7460c7814a6873bdbd38ad90d056dd66',
      'native_key' => 27,
      'filename' => 'modAction/48d7ff204571ac69711cc7f61cddba8a.vehicle',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '9b76dd270dbb918cdd940ef6f23ae867',
      'native_key' => 28,
      'filename' => 'modAction/fd9a521e0fbc688138026c05487e55b5.vehicle',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'b3f9b879c8f0236aee76860514f1838f',
      'native_key' => 29,
      'filename' => 'modAction/de23cddbfd20429a75b1f9ad843e0ed5.vehicle',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '4e7136491946bf86a285f81b7809384e',
      'native_key' => 30,
      'filename' => 'modAction/f702c9ec7a31f3d6fb3615ca42fe448b.vehicle',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'b9fa4d4b107e891a77b49effeaa366d0',
      'native_key' => 31,
      'filename' => 'modAction/336cdbd7bd4ac5c6c1e1b896f2fd4470.vehicle',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'c5bac3cb31d05edc41fa860a4f3b2b40',
      'native_key' => 32,
      'filename' => 'modAction/5a674ce787206fc4df5eb6160f777845.vehicle',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '7341b8420a20b89302d21154b449f074',
      'native_key' => 33,
      'filename' => 'modAction/80e228db3e2960d127e116c3c35f44f9.vehicle',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '85888039a562f1231c25af35543add3e',
      'native_key' => 34,
      'filename' => 'modAction/5e74b4c9962dcdef3cd9e2f0e82ad2ae.vehicle',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '2188fc25dc89c15e099eb1285b25b829',
      'native_key' => 35,
      'filename' => 'modAction/2c1e3bbd70e4006a452ddb9da6fe0a58.vehicle',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '5421424a0b3241a41152193bdf123d36',
      'native_key' => 36,
      'filename' => 'modAction/70192cf6b64e5fd749b41a57d5a43c5a.vehicle',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '1ff04380e3a54f9f249883e97c342e07',
      'native_key' => 38,
      'filename' => 'modAction/ef93210d5db1bdde3f9b1d51675753cc.vehicle',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '6c8a830a34d26e53f8cb90dc98dcd2fd',
      'native_key' => 39,
      'filename' => 'modAction/bc32eeef23423fcd51aab88f5bd7a24d.vehicle',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '6ffe8669287f987a0dd24e2e326c9383',
      'native_key' => 40,
      'filename' => 'modAction/fdf410d42b1907cb0338849056f390fe.vehicle',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'ecb168633fa3ccaf6457f3c573d770e5',
      'native_key' => 41,
      'filename' => 'modAction/6ad28176398263d67dd83fd17f02b227.vehicle',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'c34036e17cbf877b9d3c8bc2d48b620e',
      'native_key' => 43,
      'filename' => 'modAction/2dac877cbf141bfcc958cbe607d0182c.vehicle',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'c34f806ac95a26d20184edcfde1dfd1d',
      'native_key' => 46,
      'filename' => 'modAction/66270d8a12d3e5990ba70303c4ed09f6.vehicle',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '1aaaed71d19a74fee5e806baa111d6b4',
      'native_key' => 50,
      'filename' => 'modAction/ffda817faead071fb28814c54250b687.vehicle',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '125343551d9936e7fb8b0c285dbd1195',
      'native_key' => 54,
      'filename' => 'modAction/4ce8607091e20cffa5092855913eeea6.vehicle',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'f593bf564dd0371ff674522102c06fa3',
      'native_key' => 55,
      'filename' => 'modAction/b318f59b1a42d82af9662978af1aa674.vehicle',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '366947ffe3f6e5f3b8ab9fc40a1af161',
      'native_key' => 56,
      'filename' => 'modAction/d424f480cc624931095005d3cb606cb6.vehicle',
    ),
    38 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'd37a3aac552686107ecae38f7cb1e48d',
      'native_key' => 62,
      'filename' => 'modAction/13b2b87fcbeb5d27079c86144dbef190.vehicle',
    ),
    39 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '39c7136f0d264aa2151ceb465791b98f',
      'native_key' => 64,
      'filename' => 'modAction/009d598bae324a3641386b80e2b27b9c.vehicle',
    ),
    40 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '529479517677a0e1f8fbba9d850bebca',
      'native_key' => 67,
      'filename' => 'modAction/6e02bb0bfdee5bb29113e214c5696bf1.vehicle',
    ),
    41 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'ab65e42b1bba22e095d4a5a83508dd07',
      'native_key' => 70,
      'filename' => 'modAction/5edc9991c9c6a3edf030457eb45e2f6c.vehicle',
    ),
    42 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'd45bc416542b234f7bc658e307c5a430',
      'native_key' => 71,
      'filename' => 'modAction/a6d73c1310a1eeb4dcaf5206af1845f3.vehicle',
    ),
    43 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '4695365a30bd1c9d66ad553bcc5c4edf',
      'native_key' => 75,
      'filename' => 'modAction/fbee0d8b7f387e53ff14cb4d201ee4cc.vehicle',
    ),
    44 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'eea88992a1a619b110dd1e3c608fd29f',
      'native_key' => 82,
      'filename' => 'modAction/49758672812b283d8b51ff40095d0e8c.vehicle',
    ),
    45 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'f267cc2005583371cce9ea75c8f07a52',
      'native_key' => 83,
      'filename' => 'modAction/07d5156bb13f4c1809e2f2be3c82accd.vehicle',
    ),
    46 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '0de5e75bfed710280ad22fa74e5bb5b6',
      'native_key' => 84,
      'filename' => 'modAction/158e50f1311c20591ab0a9625bf5ab39.vehicle',
    ),
    47 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '02ec7659f0c677a67181943ac0d42cc1',
      'native_key' => 85,
      'filename' => 'modAction/bd2eb282da9fb48c02b7367bf14fa9e3.vehicle',
    ),
    48 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '0a7283fbc978e8a8062019b2a1036aca',
      'native_key' => 101,
      'filename' => 'modAction/8599c00b4857127e7db4692c8e711a92.vehicle',
    ),
    49 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '67241ce7ef2a6458212ba597b0f8b497',
      'native_key' => 102,
      'filename' => 'modAction/49767a192698cbb2e29a11381105b1f1.vehicle',
    ),
    50 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '5b5844e4b62151e1ecfdc65d3878b004',
      'native_key' => 103,
      'filename' => 'modAction/64ed60ac7bb20935390b171380bcd45c.vehicle',
    ),
    51 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => 'a14a1886cd6431d6010a645fde90d2e3',
      'native_key' => 104,
      'filename' => 'modAction/5610d0ab9ac3a4e9ea050bcaeefa9857.vehicle',
    ),
    52 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '9529fdc116c7d93be6c6f85f75bd51eb',
      'native_key' => 105,
      'filename' => 'modAction/4e32997c9f12b0f686ac021821ada09d.vehicle',
    ),
    53 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '7462848ed26591bd344e16a6f45eb5c7',
      'native_key' => 106,
      'filename' => 'modAction/1c86bb07674e696a3f780290fb40a6d9.vehicle',
    ),
    54 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAction',
      'guid' => '43f514c95aa1f7e0dda7dc527519d600',
      'native_key' => 107,
      'filename' => 'modAction/40ffb5139d63abee9f1cab88d11a8a95.vehicle',
    ),
    55 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'd8c1d7741d54a5a6af7dbb8bb43df5ed',
      'native_key' => 'dashboard',
      'filename' => 'modMenu/723f079a6dc4a593371e66ea384c5003.vehicle',
    ),
    56 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'cfee308a148d564172250ad1e3be0605',
      'native_key' => 'site',
      'filename' => 'modMenu/c1bfd50c411ed2b7af8da74e549bf7cc.vehicle',
    ),
    57 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '4d6acf56e55b177066cc1f5e810f7b0a',
      'native_key' => 'components',
      'filename' => 'modMenu/2a3801534267f319135026534843461c.vehicle',
    ),
    58 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '09db47c0cef314a9807314d74ca7a2a2',
      'native_key' => 'security',
      'filename' => 'modMenu/73d7904170579f98f10ed580cae4a135.vehicle',
    ),
    59 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '96084d92026052685450839c27d940c5',
      'native_key' => 'tools',
      'filename' => 'modMenu/e4116ae24fcd01dcfc25f777ccae96cb.vehicle',
    ),
    60 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '4d9c22bd791250d34a1f40101a208c46',
      'native_key' => 'reports',
      'filename' => 'modMenu/8831358c5768f3528d280c8691326150.vehicle',
    ),
    61 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'ff824294a302f56f871c2240fdc856ca',
      'native_key' => 'system',
      'filename' => 'modMenu/dcfe4347e9c98135fc5aa12d5c73f132.vehicle',
    ),
    62 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'b8edf3b1bb08124fe11658e71d148546',
      'native_key' => 'user',
      'filename' => 'modMenu/c4f95c538991434c980671bb97df90b1.vehicle',
    ),
    63 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'b38309ff157aee83b898aa30df04f431',
      'native_key' => 'support',
      'filename' => 'modMenu/87e43af8cb28b3dea8b28c3438a6ba3b.vehicle',
    ),
    64 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '4ee241d713a9d75d87737ab585ac0802',
      'native_key' => 1,
      'filename' => 'modContentType/9cc5b0806595a0207b4517136ca8c9f7.vehicle',
    ),
    65 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '0762098ba60464522574bea3a808bb9c',
      'native_key' => 2,
      'filename' => 'modContentType/7474556520e8e566f457a52a070464ed.vehicle',
    ),
    66 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '7b030b2503b99c5acc90d100656a1107',
      'native_key' => 3,
      'filename' => 'modContentType/bb043cdb70521d0abfbeef0a88f05cc8.vehicle',
    ),
    67 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '657f58eb7a26695948269404ceb41450',
      'native_key' => 4,
      'filename' => 'modContentType/ca86e649988feb3bdab79be89b2864ed.vehicle',
    ),
    68 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'a6cd9d0f929fd0fe1042b6219554ff46',
      'native_key' => 5,
      'filename' => 'modContentType/9154aabe41f27989f89b29f4c98b7685.vehicle',
    ),
    69 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '01323ec4e39a5bf830d4d74de18ecf6d',
      'native_key' => 6,
      'filename' => 'modContentType/ccb662b3cfbadd660cb3cc9f76375f11.vehicle',
    ),
    70 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '78958d873c67c247ac9bc3f8bda96607',
      'native_key' => 7,
      'filename' => 'modContentType/00cf875ca74086c34307bb0acdcffcf8.vehicle',
    ),
    71 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '3eeff4d48a5e03e3371d3c51a7199604',
      'native_key' => NULL,
      'filename' => 'modClassMap/8ad19c4cdbf64e6db6db1655191ca6ba.vehicle',
    ),
    72 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'd8174348daa49c90152e14637e93d1d5',
      'native_key' => NULL,
      'filename' => 'modClassMap/7b188ab8805559167c80e9a49f1b5682.vehicle',
    ),
    73 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '2ada36acde6f017cf4f845b66eaed8f1',
      'native_key' => NULL,
      'filename' => 'modClassMap/766211b15850788f2cbc7cf11e79b7cf.vehicle',
    ),
    74 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '9b4b2530ac7fcc02d1427c56fea8836e',
      'native_key' => NULL,
      'filename' => 'modClassMap/0dd8b2cf43aed054811df5d71332c84f.vehicle',
    ),
    75 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '960451f640085b655820f2cb6aca3fd6',
      'native_key' => NULL,
      'filename' => 'modClassMap/064fafa7af315ac7ae48fe2bc6b04155.vehicle',
    ),
    76 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '44b7018ed649989608255ace4214ce92',
      'native_key' => NULL,
      'filename' => 'modClassMap/5a1674915ed15202790a46a6b8a925c6.vehicle',
    ),
    77 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '1e3821e59fa543f3ef59f24dd1d560f6',
      'native_key' => NULL,
      'filename' => 'modClassMap/7f2d3034f85e7ea5f4da29d56991d905.vehicle',
    ),
    78 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '5129a825a9b1cb3f94eb1d6749d82c15',
      'native_key' => NULL,
      'filename' => 'modClassMap/637094ba33fa4b019824b3cc51779333.vehicle',
    ),
    79 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '2959c1e96a3af7d2f66ed66edb102871',
      'native_key' => NULL,
      'filename' => 'modClassMap/4efe74e28f53367f033efcfdd5c00fe1.vehicle',
    ),
    80 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7f8b6c0f8d7c37382dcb67faa95a63bc',
      'native_key' => 'OnPluginEventBeforeSave',
      'filename' => 'modEvent/6d7615aab4f955a79ae34a00e7f15f41.vehicle',
    ),
    81 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7a0a909019d9871a8f265e5eea6de20a',
      'native_key' => 'OnPluginEventSave',
      'filename' => 'modEvent/75cd8101366e7218f042ea640b449b17.vehicle',
    ),
    82 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd434ea155cc14c6c9300ad2e09020872',
      'native_key' => 'OnPluginEventBeforeRemove',
      'filename' => 'modEvent/23fa9f327445555eeac0de79e7a5132a.vehicle',
    ),
    83 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bfa9ab6ac81d25b7e56b86ee9bbfed2b',
      'native_key' => 'OnPluginEventRemove',
      'filename' => 'modEvent/5ebd38907c054fb94ce576d92cf4ef41.vehicle',
    ),
    84 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2e528a98004eed331344c120faad0d4a',
      'native_key' => 'OnResourceGroupSave',
      'filename' => 'modEvent/39aa1027db15f2939f9d1be49d529c25.vehicle',
    ),
    85 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b2042a9236c8a6f5452b7b1fac78eb2d',
      'native_key' => 'OnResourceGroupBeforeSave',
      'filename' => 'modEvent/fb93ecc840f83f04a5eac5353c245fc8.vehicle',
    ),
    86 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'af5bd06cc1972ec6f25924e2eb44341f',
      'native_key' => 'OnResourceGroupRemove',
      'filename' => 'modEvent/6de3718a051d3f056da59c480057c2bc.vehicle',
    ),
    87 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f6030f460b15796f3d3793038f2e3657',
      'native_key' => 'OnResourceGroupBeforeRemove',
      'filename' => 'modEvent/aa02e5779f14ede5325ea2e054365823.vehicle',
    ),
    88 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '43e468dedc83fa583ea90dc25db4fa4b',
      'native_key' => 'OnSnippetBeforeSave',
      'filename' => 'modEvent/837e23db33861822d6c411a2c14349d3.vehicle',
    ),
    89 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '60ad99d5c6fb9337907f06419d57fb4c',
      'native_key' => 'OnSnippetSave',
      'filename' => 'modEvent/3c41bca89829271a011c601d801d4c26.vehicle',
    ),
    90 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9e5517bdccb1ae0c73e1d772e319efb7',
      'native_key' => 'OnSnippetBeforeRemove',
      'filename' => 'modEvent/233183acd5195337c332d5f8fd2ca5ce.vehicle',
    ),
    91 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1846e34ae95b34eaff0d01b0a85fb8f3',
      'native_key' => 'OnSnippetRemove',
      'filename' => 'modEvent/931fadeb04d121da29e14679ebc58c16.vehicle',
    ),
    92 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3c80c23fa0377c788d50480cfe3530c0',
      'native_key' => 'OnSnipFormPrerender',
      'filename' => 'modEvent/e903ac53f9771615622aef3fd2c7d49c.vehicle',
    ),
    93 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9023f56c941288cc6fff070b3cb0bf8d',
      'native_key' => 'OnSnipFormRender',
      'filename' => 'modEvent/3fa1527b77ce22ec5658ace064abad1b.vehicle',
    ),
    94 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5c0441bd1ac4270cd7cfa8d939facbea',
      'native_key' => 'OnBeforeSnipFormSave',
      'filename' => 'modEvent/8b1ca214d7fe01b473e3099e1e3cd9b4.vehicle',
    ),
    95 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '71e5d32426b4d2024d31bf77091c6fa8',
      'native_key' => 'OnSnipFormSave',
      'filename' => 'modEvent/782bf8339dd4d68a55e01596d7f5117e.vehicle',
    ),
    96 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '182814c7e251ae53c80fdfe8e687dd47',
      'native_key' => 'OnBeforeSnipFormDelete',
      'filename' => 'modEvent/61f9dde54055d898954587167ffe6e36.vehicle',
    ),
    97 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1ff850d01ac72cd7f8e501b7279e7548',
      'native_key' => 'OnSnipFormDelete',
      'filename' => 'modEvent/640fe4a4e63b151c406c3c30eb6aab01.vehicle',
    ),
    98 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a601e8cf82b64c11b33d0826cca16161',
      'native_key' => 'OnTemplateBeforeSave',
      'filename' => 'modEvent/a8deaddddae49c9c4802bebca83aabdc.vehicle',
    ),
    99 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5538111986e002c0fde4972c2852c160',
      'native_key' => 'OnTemplateSave',
      'filename' => 'modEvent/db7fc2bfa6e9d28bd2a41bbe59710d02.vehicle',
    ),
    100 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd1ee6e737a76d964fb7bff1019b03792',
      'native_key' => 'OnTemplateBeforeRemove',
      'filename' => 'modEvent/85206e2455aa55e8ee21f929e8829c82.vehicle',
    ),
    101 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1d9ba4aa7aba6cb8f79a8c3b52d83ae2',
      'native_key' => 'OnTemplateRemove',
      'filename' => 'modEvent/59d546959ae640c3f6a221c6cbcaa97f.vehicle',
    ),
    102 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1374c46df7cd6d5a6e06579c125fbe19',
      'native_key' => 'OnTempFormPrerender',
      'filename' => 'modEvent/d8c0e61e6404e1c37c5983d3a1b2ca58.vehicle',
    ),
    103 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bacc88d3fd1b87a373ea70b3094d76c9',
      'native_key' => 'OnTempFormRender',
      'filename' => 'modEvent/807d2a5369687b83ecbba3dfa4febf7a.vehicle',
    ),
    104 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ba9c90c7adc98db835d600eaafbc4a7e',
      'native_key' => 'OnBeforeTempFormSave',
      'filename' => 'modEvent/4f966bb342ab73b0c78886fcb414eada.vehicle',
    ),
    105 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '48c2bac5735e3eede51e2439222868f7',
      'native_key' => 'OnTempFormSave',
      'filename' => 'modEvent/776aca8e77650560685d29a403f68d67.vehicle',
    ),
    106 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '329f4afab9ba4bc04add44bdf648d2ce',
      'native_key' => 'OnBeforeTempFormDelete',
      'filename' => 'modEvent/9c3710b9e8fb6d7d66c0fc4b134beb88.vehicle',
    ),
    107 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '564cdab9160273330f2440f0739394cb',
      'native_key' => 'OnTempFormDelete',
      'filename' => 'modEvent/ae5dd6d6274725c9910b78314648523b.vehicle',
    ),
    108 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7e5f0065a7447225770f78e2e4df4a0f',
      'native_key' => 'OnTemplateVarBeforeSave',
      'filename' => 'modEvent/708a72d96bc8981f51802f6f7e24ff91.vehicle',
    ),
    109 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6ffcd6c01385ce097b72b0577859e8b2',
      'native_key' => 'OnTemplateVarSave',
      'filename' => 'modEvent/7be62848a0f073f29097f2f8686596de.vehicle',
    ),
    110 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0c35a27defcff16941f8f948336c4314',
      'native_key' => 'OnTemplateVarBeforeRemove',
      'filename' => 'modEvent/065d46e6d23ef16e31d7cbeacf0d7ac5.vehicle',
    ),
    111 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6c3ee276aa1da6bc7280a880a07e04a7',
      'native_key' => 'OnTemplateVarRemove',
      'filename' => 'modEvent/89fbd0128df9aae8886bff8b1210cf36.vehicle',
    ),
    112 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6af8adbe05dae598e38b512464cb23a6',
      'native_key' => 'OnTVFormPrerender',
      'filename' => 'modEvent/b4dc3319a170655cefffc4c76519f549.vehicle',
    ),
    113 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '937aaa6daed435af94121277333633c9',
      'native_key' => 'OnTVFormRender',
      'filename' => 'modEvent/e866ef8af74dbc09835e2fb29e6152e5.vehicle',
    ),
    114 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0213774209224f81ac469880a4b908cd',
      'native_key' => 'OnBeforeTVFormSave',
      'filename' => 'modEvent/0608047035b5e87eedd0d258711a46a4.vehicle',
    ),
    115 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fc69941a5f33d4bb7e5ddd160f32ad97',
      'native_key' => 'OnTVFormSave',
      'filename' => 'modEvent/8241e3880f876356cc23310dff6d2a06.vehicle',
    ),
    116 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b8749e19fe235342491c830d078ecda8',
      'native_key' => 'OnBeforeTVFormDelete',
      'filename' => 'modEvent/30e31bccbef72f010ac3b75322b633b1.vehicle',
    ),
    117 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8e8d582c90e0cdd66449f6aae040f13c',
      'native_key' => 'OnTVFormDelete',
      'filename' => 'modEvent/0dc018c6ae4b84b8932408e36139a5e3.vehicle',
    ),
    118 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd19c4e8f1fe010dab7e050f55d9b4827',
      'native_key' => 'OnTVInputRenderList',
      'filename' => 'modEvent/e39c102483219df7d4f96f6b5efd54b1.vehicle',
    ),
    119 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2f31b4846b0cfb57e12b0457330e7d4e',
      'native_key' => 'OnTVInputPropertiesList',
      'filename' => 'modEvent/68eab2fb631d068d80e6b407ce2fd5f3.vehicle',
    ),
    120 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4f22a32e77b740f7c7ae6038f4fa153a',
      'native_key' => 'OnTVOutputRenderList',
      'filename' => 'modEvent/31622ab06dcb8777a2e72f33f135837d.vehicle',
    ),
    121 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b6ca69a7ba8563251dc00ad44bbb0f71',
      'native_key' => 'OnTVOutputRenderPropertiesList',
      'filename' => 'modEvent/2f196f7fee98ad0d835c3c3b29a4278d.vehicle',
    ),
    122 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5f16e5bcff3ec3bf28eed8ca2e35f15a',
      'native_key' => 'OnUserGroupBeforeSave',
      'filename' => 'modEvent/715864056db6f4bdf7d7e11b47633075.vehicle',
    ),
    123 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '77aa9d2d53072493f2a5ca88239368c2',
      'native_key' => 'OnUserGroupSave',
      'filename' => 'modEvent/b3db286a9ce5d20e1a734b0e08b9e46c.vehicle',
    ),
    124 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd7a79eac1de90c6283adea6795c24b71',
      'native_key' => 'OnUserGroupBeforeRemove',
      'filename' => 'modEvent/f292c51ab765250a64717ce44b1f3754.vehicle',
    ),
    125 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c6f24232391b39a2ea49710ce6be66b0',
      'native_key' => 'OnUserGroupRemove',
      'filename' => 'modEvent/bc77736662021f8fbd7bae8d9790dbfb.vehicle',
    ),
    126 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a2514b956ba3a62926b508ffc7a506eb',
      'native_key' => 'OnBeforeUserGroupFormSave',
      'filename' => 'modEvent/478553b3266b1a6ee8eecb01240c29ac.vehicle',
    ),
    127 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c41c51396020cab990a2afdd12abc2b4',
      'native_key' => 'OnUserGroupFormSave',
      'filename' => 'modEvent/e16c1ea7a67bcdb413b4b888966d373c.vehicle',
    ),
    128 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9ec29624182b92d81bf85c6081be387c',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/2b068301c01c6380f61308205bba03bd.vehicle',
    ),
    129 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd398725d0f3c9a9d83416410e06d5795',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/34db530cc75a947a1ff385447d93883e.vehicle',
    ),
    130 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a271bebe40c3f7888c8d0bcfc13273d5',
      'native_key' => 'OnDocFormPrerender',
      'filename' => 'modEvent/388f905a3caca1cc3af494f66272d51d.vehicle',
    ),
    131 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '30e8dc28507b9c895d877512cd621661',
      'native_key' => 'OnDocFormRender',
      'filename' => 'modEvent/392da1cf377ef8edda8969ddd8cfd6e3.vehicle',
    ),
    132 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a3cf18db1491acabc1066a80d36470f0',
      'native_key' => 'OnBeforeDocFormSave',
      'filename' => 'modEvent/e146c6634ce1806d0f52f60d359e489c.vehicle',
    ),
    133 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4e2acb6f462cd15d65c2acd08b42569a',
      'native_key' => 'OnDocFormSave',
      'filename' => 'modEvent/531feec20c7927b0329e6019d0c72ef3.vehicle',
    ),
    134 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8fe3061b22228cc63aab17824e2562d5',
      'native_key' => 'OnBeforeDocFormDelete',
      'filename' => 'modEvent/1050cf2c044226d5d2a4691365e142d1.vehicle',
    ),
    135 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '95e2fad51a68adc6fdfd0e0f784a0e39',
      'native_key' => 'OnDocFormDelete',
      'filename' => 'modEvent/91f9006f00ead16e8f8647e5d473cfd2.vehicle',
    ),
    136 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '825aadf5cfd1d395797ecaccbd0acb75',
      'native_key' => 'OnDocPublished',
      'filename' => 'modEvent/1a7aa4d4f877dfb2746283a0fe28fd4e.vehicle',
    ),
    137 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '90335aaa0877592057e7088574f194d6',
      'native_key' => 'OnDocUnPublished',
      'filename' => 'modEvent/1f82f0e331f1cf04af848f5babbcd556.vehicle',
    ),
    138 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '364a8f731f00019585224df2b6ff1da6',
      'native_key' => 'OnBeforeEmptyTrash',
      'filename' => 'modEvent/426e69c49364b46fd122d651a652fb9d.vehicle',
    ),
    139 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '45bf5491e51a7c8a76598c639853a8fa',
      'native_key' => 'OnEmptyTrash',
      'filename' => 'modEvent/580ef41e29c89e8991bdd4807f9b25c2.vehicle',
    ),
    140 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4fcf8b4d776e81c47c279a26e651bbdc',
      'native_key' => 'OnResourceTVFormPrerender',
      'filename' => 'modEvent/02c28b463e78b407f2d1f253e91e13dd.vehicle',
    ),
    141 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ff3e1150ec9f185251544b00fd1ad06e',
      'native_key' => 'OnResourceTVFormRender',
      'filename' => 'modEvent/a8fc7e543ccae54cc5e527bec9a18d3f.vehicle',
    ),
    142 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '943391326d92719e7fb298a867d09430',
      'native_key' => 'OnResourceDelete',
      'filename' => 'modEvent/1177b80d6b441c64a496896464d8c615.vehicle',
    ),
    143 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dc98d9c435e897a32c32d687bff32eae',
      'native_key' => 'OnResourceUndelete',
      'filename' => 'modEvent/752ff55654223cd46b173d72daf1cff5.vehicle',
    ),
    144 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bdcc6992c129dc2b39f76588d4b584ea',
      'native_key' => 'OnResourceBeforeSort',
      'filename' => 'modEvent/1a80eda636895ee5272ada96b9f533bf.vehicle',
    ),
    145 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a62cdae30c80a5e2d87cd2d4bf76b0de',
      'native_key' => 'OnResourceSort',
      'filename' => 'modEvent/a8a06b1f3770bf9984e4a533482f1b95.vehicle',
    ),
    146 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd31c529f96d808ea4a4ae89655ff9b1c',
      'native_key' => 'OnResourceDuplicate',
      'filename' => 'modEvent/228deb16ab62103e8f87cdd22ae77398.vehicle',
    ),
    147 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'da19f45b23238e84c893a544d1084bef',
      'native_key' => 'OnResourceToolbarLoad',
      'filename' => 'modEvent/b70e71fd8394264084226492a26fc31c.vehicle',
    ),
    148 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2765e51e2a270708654a34b82046c50b',
      'native_key' => 'OnResourceRemoveFromResourceGroup',
      'filename' => 'modEvent/725ba24eb93d9f93d495dadc6dbf8575.vehicle',
    ),
    149 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a180839bc0fb3c1cb65bd3b09e330b4c',
      'native_key' => 'OnResourceAddToResourceGroup',
      'filename' => 'modEvent/813e0be347e1bca2df88d8f6682269b3.vehicle',
    ),
    150 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c3f42b25ca3856418e011c618e556d90',
      'native_key' => 'OnRichTextEditorRegister',
      'filename' => 'modEvent/b4e6117da4650b47200e1d436628e2fc.vehicle',
    ),
    151 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7878dddd6fa681132421c14fcd47da5b',
      'native_key' => 'OnRichTextEditorInit',
      'filename' => 'modEvent/c8526d83104a637d416b75a653566e6c.vehicle',
    ),
    152 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '39ddf33f69eebfa42b1b04d6992d7834',
      'native_key' => 'OnRichTextBrowserInit',
      'filename' => 'modEvent/3dfe96fdd45cf5a0fd3fa04f7c769847.vehicle',
    ),
    153 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7ff77296398c94a1d8a0051eae50d738',
      'native_key' => 'OnWebLogin',
      'filename' => 'modEvent/e316b4a67bbf77c6a27bd28e38716def.vehicle',
    ),
    154 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '23bf65460c71ecd29e29726461243bbe',
      'native_key' => 'OnBeforeWebLogout',
      'filename' => 'modEvent/e7ad6657010f87171dcf1b88fff25d85.vehicle',
    ),
    155 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '642546f7806e791405a45ae5f00da421',
      'native_key' => 'OnWebLogout',
      'filename' => 'modEvent/2ac89dbad536d944df13e5718cb53f1f.vehicle',
    ),
    156 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '920aa79c7d721c426f2ccce5957c9c94',
      'native_key' => 'OnManagerLogin',
      'filename' => 'modEvent/491b60debf49b45d824bc6718d121bef.vehicle',
    ),
    157 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9ec1d91fca838a2893c6e4bac92e2a1d',
      'native_key' => 'OnBeforeManagerLogout',
      'filename' => 'modEvent/abbcfc35a063267c8e052a57e3575767.vehicle',
    ),
    158 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '70a3016c2046158b3120e3d509d86447',
      'native_key' => 'OnManagerLogout',
      'filename' => 'modEvent/c60b08f62165d55fddadf4c785b509dc.vehicle',
    ),
    159 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ff796520d012f25c5601a702a09a3819',
      'native_key' => 'OnBeforeWebLogin',
      'filename' => 'modEvent/506b9e46441a95379e7c040066e77cd7.vehicle',
    ),
    160 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2f1673f0a1455ce51b6183448c86916a',
      'native_key' => 'OnWebAuthentication',
      'filename' => 'modEvent/f9205aa49a19672cedb4d819a80e1ecb.vehicle',
    ),
    161 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3db4c3563ba43be2ecdf4c1b100cd53c',
      'native_key' => 'OnBeforeManagerLogin',
      'filename' => 'modEvent/d51593cb02c3f86898e0ebb1e4d3742b.vehicle',
    ),
    162 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4d083d468b23de6e5a0e34e2684a4d4a',
      'native_key' => 'OnManagerAuthentication',
      'filename' => 'modEvent/56bd5f8d6edf9c67530cb0013dda7cb9.vehicle',
    ),
    163 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '23b48a00cd64d5f16fe003cd7d797d2f',
      'native_key' => 'OnManagerLoginFormRender',
      'filename' => 'modEvent/8d79070c79e40bbf16b40c4ab5f424ed.vehicle',
    ),
    164 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '25ba4359d3f05ad877b93b7b6a6d06d1',
      'native_key' => 'OnManagerLoginFormPrerender',
      'filename' => 'modEvent/39f77c9152a844f789d50e6cf4f8f679.vehicle',
    ),
    165 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'abc1f9dbb131a5b4551641e48bb2360a',
      'native_key' => 'OnPageUnauthorized',
      'filename' => 'modEvent/08ea49c05220fcc33c4d2b6c3f438a68.vehicle',
    ),
    166 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'eed9e35dc082f703de97939903885e68',
      'native_key' => 'OnUserFormPrerender',
      'filename' => 'modEvent/62834aeb2907e15e4f9b8e18799efa7d.vehicle',
    ),
    167 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6c75aec9a573ea32c9ffbe6f68669936',
      'native_key' => 'OnUserFormRender',
      'filename' => 'modEvent/705e7a774b6254856f64dd1d019a31c9.vehicle',
    ),
    168 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2aac27d08e8427ac65f05b7e0e0671de',
      'native_key' => 'OnBeforeUserFormSave',
      'filename' => 'modEvent/c7ef1644cecff85a67007a858cc69d36.vehicle',
    ),
    169 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4b4cb0ae1b9013a469bf1764656fe236',
      'native_key' => 'OnUserFormSave',
      'filename' => 'modEvent/41a9d921c21825e6243a82a230051527.vehicle',
    ),
    170 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9a6108f6b0c3c847308179019a640291',
      'native_key' => 'OnBeforeUserFormDelete',
      'filename' => 'modEvent/16a3e051a14b857c2a5facdd66c5f14c.vehicle',
    ),
    171 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f880d57655c4e68cf754075c5eca79c2',
      'native_key' => 'OnUserFormDelete',
      'filename' => 'modEvent/57bb316253eee8c5d7743523cda85643.vehicle',
    ),
    172 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '26af355468b7460256250cda8770c4c6',
      'native_key' => 'OnUserNotFound',
      'filename' => 'modEvent/3dbb8246236815d77da76007007131bc.vehicle',
    ),
    173 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8f170c5ec1c33bd11b3d53d1659511f3',
      'native_key' => 'OnBeforeUserActivate',
      'filename' => 'modEvent/924797b22ab356e89f15bd43610cb165.vehicle',
    ),
    174 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bb0c3e27c8ae1371f69326812ac1d4b5',
      'native_key' => 'OnUserActivate',
      'filename' => 'modEvent/055e2b6516bcd3b56df32a62010ed236.vehicle',
    ),
    175 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cfb3cf302c28984a5f8cc84197a9d2ab',
      'native_key' => 'OnBeforeUserDeactivate',
      'filename' => 'modEvent/7bd282a5168b12fbe82dc0d2426c1b1c.vehicle',
    ),
    176 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6390db4125671ece559f8e37774c93de',
      'native_key' => 'OnUserDeactivate',
      'filename' => 'modEvent/28770ee7c7ba0e09467f314a434ef397.vehicle',
    ),
    177 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5cb45c65a16ab67f9ea0e744e2d57fa7',
      'native_key' => 'OnBeforeUserDuplicate',
      'filename' => 'modEvent/8b186c2c92309aa5b832dccc4c69b6a3.vehicle',
    ),
    178 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e77958b029c39fadd763d59ca4f4dc72',
      'native_key' => 'OnUserDuplicate',
      'filename' => 'modEvent/89b36546cd0dfa644e2f11134562c777.vehicle',
    ),
    179 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '87646220946f4ba6068edcce823e41fc',
      'native_key' => 'OnUserChangePassword',
      'filename' => 'modEvent/58863120bb28209a903f03830942d06c.vehicle',
    ),
    180 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '39aac5e28a45c72b864c31c0d2913c5f',
      'native_key' => 'OnUserBeforeRemove',
      'filename' => 'modEvent/1e1a27088d8f9087f18872049d0eadfb.vehicle',
    ),
    181 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f89cbb66e7791df6698904165443a454',
      'native_key' => 'OnUserBeforeSave',
      'filename' => 'modEvent/239589b34b7b736568442ad3a03204d6.vehicle',
    ),
    182 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7b69c9f9787cd7f45d1458f18bab0bd2',
      'native_key' => 'OnUserSave',
      'filename' => 'modEvent/b2d20cec254b86b49c175634946051d0.vehicle',
    ),
    183 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f5ec46c956a81b9fca87109b42304925',
      'native_key' => 'OnUserRemove',
      'filename' => 'modEvent/dbb363f57e672ef988caa37375b724f5.vehicle',
    ),
    184 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '943de6481eee189627ca3b3fd7746a48',
      'native_key' => 'OnUserBeforeAddToGroup',
      'filename' => 'modEvent/9d1a0f632e6bde70a6ef7d50d1990df2.vehicle',
    ),
    185 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '66558191ed499b5c4cecd6a4b953469a',
      'native_key' => 'OnUserAddToGroup',
      'filename' => 'modEvent/fcd32e4b7476a2e6e9de66214bb13778.vehicle',
    ),
    186 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '97c670cfb3bb17bf471496f3f39ea94d',
      'native_key' => 'OnUserBeforeRemoveFromGroup',
      'filename' => 'modEvent/33de870d25fd47d17ff89c00acf78f77.vehicle',
    ),
    187 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ed14d1db74c2f5c3dbfd89c5483151ba',
      'native_key' => 'OnUserRemoveFromGroup',
      'filename' => 'modEvent/9a2ac65c9caf5b7892f446ac3141b8e3.vehicle',
    ),
    188 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3e110ff176c263da12113426b94d9276',
      'native_key' => 'OnWebPagePrerender',
      'filename' => 'modEvent/ec05aa26252457b10bf50fc57f183e25.vehicle',
    ),
    189 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f522333c8da43337c10791f0897a3ea5',
      'native_key' => 'OnBeforeCacheUpdate',
      'filename' => 'modEvent/49c0b82e0336a6fa4ba1ad20dde10e3b.vehicle',
    ),
    190 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bd1755967fd42b5a67cf08e73eff5d7a',
      'native_key' => 'OnCacheUpdate',
      'filename' => 'modEvent/bf3db5300d9e965167f02ce1f42ffe25.vehicle',
    ),
    191 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9559f938397c42a5b2925f3995a5526b',
      'native_key' => 'OnLoadWebPageCache',
      'filename' => 'modEvent/b94d065c8d2e6c05fdad8ce54a90f915.vehicle',
    ),
    192 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4d5cd7cc4837c0f4a35cf108c16305d0',
      'native_key' => 'OnBeforeSaveWebPageCache',
      'filename' => 'modEvent/4217e059f6301b7f2d3a494087f9c470.vehicle',
    ),
    193 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ba52c14bf01a94b7d9833d6b4fe32050',
      'native_key' => 'OnSiteRefresh',
      'filename' => 'modEvent/e3c1978e02baaaee941811019f6a66a1.vehicle',
    ),
    194 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6066098858da9319816499f09638c5e1',
      'native_key' => 'OnFileManagerUpload',
      'filename' => 'modEvent/1c3d3e85c455950542217d256365c62a.vehicle',
    ),
    195 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '10736e1b2f3e366c1408717d6d450c02',
      'native_key' => 'OnFileCreateFormPrerender',
      'filename' => 'modEvent/304468180f6a2f87da0bee5cef05b906.vehicle',
    ),
    196 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '03d7034ed899c34bbcaa9fc18cd03fee',
      'native_key' => 'OnFileEditFormPrerender',
      'filename' => 'modEvent/1d141cf35503ba568653455cc3f188a9.vehicle',
    ),
    197 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f83a47b5484296723fdc2f1bc5d9eab1',
      'native_key' => 'OnManagerPageInit',
      'filename' => 'modEvent/cd1a8abf134acf77fd8af1f4d97aed87.vehicle',
    ),
    198 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '42305e55ee56dd01d408ea79da0a0b8a',
      'native_key' => 'OnManagerPageBeforeRender',
      'filename' => 'modEvent/d4f28da33e5cd8404162693221740334.vehicle',
    ),
    199 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'de874d7cd86f1f6706435a01d133da7b',
      'native_key' => 'OnManagerPageAfterRender',
      'filename' => 'modEvent/8de437fb9855a2493a5cfbd6250a4c45.vehicle',
    ),
    200 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '23ffb0bd1b0c813ab8f2ec546d098dd6',
      'native_key' => 'OnWebPageInit',
      'filename' => 'modEvent/d08c693c71587ae68d370a3e6dc6d618.vehicle',
    ),
    201 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f9c0c7d8bad9f83b9de13acc33144a22',
      'native_key' => 'OnLoadWebDocument',
      'filename' => 'modEvent/ab23c9a885bffb2f97775e20647f8f3f.vehicle',
    ),
    202 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b56b79b4ce0040466d670118afa6cf89',
      'native_key' => 'OnParseDocument',
      'filename' => 'modEvent/dc59abce3c74228077d82bbeaf2d64ce.vehicle',
    ),
    203 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c0b2d406407eb18bccf16cb11ef67f76',
      'native_key' => 'OnWebPageComplete',
      'filename' => 'modEvent/aa2b1a174da1b51ad9709d8670b11759.vehicle',
    ),
    204 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5304b80795bdd66116f4bd02ac374e52',
      'native_key' => 'OnBeforeManagerPageInit',
      'filename' => 'modEvent/5daa7f79853f143d8f01b24f58e1ce3a.vehicle',
    ),
    205 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5a80c6f2b5b606baf636bafd6db188e7',
      'native_key' => 'OnPageNotFound',
      'filename' => 'modEvent/c90e8fc527be191ba27d7c5d0ddd72f7.vehicle',
    ),
    206 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '494ba4056580c9e6d7aba0ad7040617b',
      'native_key' => 'OnHandleRequest',
      'filename' => 'modEvent/2796433b443728901553dcfd6f8782f0.vehicle',
    ),
    207 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '74f1f1f5496630e0b43b8815c6b73b1d',
      'native_key' => 'OnSiteSettingsRender',
      'filename' => 'modEvent/75d9e44c29b8e73c5ce63e099fb455ac.vehicle',
    ),
    208 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'af49d6c17d3e5be0476bccdbbf68f157',
      'native_key' => 'OnInitCulture',
      'filename' => 'modEvent/bd4190be7b3c29ed2a7fd87b97f4f398.vehicle',
    ),
    209 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4475cb2a933ed054102276f6f66f28bf',
      'native_key' => 'OnCategorySave',
      'filename' => 'modEvent/67f113fe263fbea5d71043b2643a7e35.vehicle',
    ),
    210 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e70bd8b962608c2747c43e0a9cf6a608',
      'native_key' => 'OnCategoryBeforeSave',
      'filename' => 'modEvent/8467c88c6d98df8e7ce214dec119bd68.vehicle',
    ),
    211 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9e1aaf0f09b5936264ba42b9e45c280c',
      'native_key' => 'OnCategoryRemove',
      'filename' => 'modEvent/8fb29fc4993b01d53ea3829950678fdc.vehicle',
    ),
    212 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4d0a41ac97e873d13db74bf629cde3a3',
      'native_key' => 'OnCategoryBeforeRemove',
      'filename' => 'modEvent/d4efabdda6bc56a7052e0a359b0eadd8.vehicle',
    ),
    213 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'edfc9c68ea3092497284f8fc96dc1a67',
      'native_key' => 'OnChunkSave',
      'filename' => 'modEvent/46d77eb5d4fafcbaf4a74294df9a7d27.vehicle',
    ),
    214 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b3f5732d1d8f60fffb2027642e32515b',
      'native_key' => 'OnChunkBeforeSave',
      'filename' => 'modEvent/a4c3521f6ab6ff1b10193582f7a6cd28.vehicle',
    ),
    215 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bcdb1e94784e0b8708eb427cc1ff98b5',
      'native_key' => 'OnChunkRemove',
      'filename' => 'modEvent/ed6218509753078ae29ccfdcc685c8ee.vehicle',
    ),
    216 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2d7a4b06c482a79c98282e574ae89939',
      'native_key' => 'OnChunkBeforeRemove',
      'filename' => 'modEvent/486503aa47e7005b774a914a472f20b9.vehicle',
    ),
    217 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3344f66838c3d5807d6421c9b75041f3',
      'native_key' => 'OnChunkFormPrerender',
      'filename' => 'modEvent/2e200e2dabcf374c616d6cf7bec97a20.vehicle',
    ),
    218 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '229003e3d38fae020df7079feade9c0a',
      'native_key' => 'OnChunkFormRender',
      'filename' => 'modEvent/6f7ff4fb3cbfcf6f89e86e9335a0bebd.vehicle',
    ),
    219 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1c0cbf1bddb5de63a3b7f96d6823febd',
      'native_key' => 'OnBeforeChunkFormSave',
      'filename' => 'modEvent/59d4c3f5d4bccbb7c86b69dac3e28d05.vehicle',
    ),
    220 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b8dd89bdea01f1f647e4297d4f1f5bcf',
      'native_key' => 'OnChunkFormSave',
      'filename' => 'modEvent/f56555ad7257a0e8925ec1158e007984.vehicle',
    ),
    221 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '51dc2384983f7ff5f696c4d954e46e82',
      'native_key' => 'OnBeforeChunkFormDelete',
      'filename' => 'modEvent/9516a79f725bcaf25035dc7b9cc2e8d0.vehicle',
    ),
    222 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd2825f73e26b52341e38712ff1a02f88',
      'native_key' => 'OnChunkFormDelete',
      'filename' => 'modEvent/6ec0e57a1471017e7d5512ff74b4cf95.vehicle',
    ),
    223 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4dbdecd1bec81fe311b74d6fa261cdc2',
      'native_key' => 'OnContextSave',
      'filename' => 'modEvent/813032f559c40c69148328774fc48122.vehicle',
    ),
    224 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b306e265ac596665af2f74770bb5f0c6',
      'native_key' => 'OnContextBeforeSave',
      'filename' => 'modEvent/e308b292923f3ade2329f616bbc546e2.vehicle',
    ),
    225 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '35365b6e564128506ca4bc0357accea4',
      'native_key' => 'OnContextRemove',
      'filename' => 'modEvent/5151c6a7b83b465e7449759a41bc92cf.vehicle',
    ),
    226 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '96369748910f4b27b8cde399c7ca80dd',
      'native_key' => 'OnContextBeforeRemove',
      'filename' => 'modEvent/a91fad34dd702f4c9d51cef229112bb9.vehicle',
    ),
    227 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4b509d7aaa11047525f93df123febe49',
      'native_key' => 'OnContextFormPrerender',
      'filename' => 'modEvent/a03972d9f0562c83fcc2364f27a1478a.vehicle',
    ),
    228 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0cb0951346bba5d943ca58f9b419fe40',
      'native_key' => 'OnContextFormRender',
      'filename' => 'modEvent/d1ba489e0710cec66a71c1891fe6cd13.vehicle',
    ),
    229 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3baaffbe5df24131237fc0ad2e356fe8',
      'native_key' => 'OnPluginSave',
      'filename' => 'modEvent/900baa66856d8754371353ac00f8ee0b.vehicle',
    ),
    230 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'aadc8ae9ffda2c1650dd448e94800ed0',
      'native_key' => 'OnPluginBeforeSave',
      'filename' => 'modEvent/cca3793e62dd3f861a7a0318a94ab748.vehicle',
    ),
    231 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ff74a45f48c86d44c1638af895ccdc04',
      'native_key' => 'OnPluginRemove',
      'filename' => 'modEvent/f92e3ffa100648e85c1a26fbf30e454f.vehicle',
    ),
    232 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1bd94341d3ef75c5650fd1aa3eca88aa',
      'native_key' => 'OnPluginBeforeRemove',
      'filename' => 'modEvent/162a2a227c059a62fa5073893eff7e2f.vehicle',
    ),
    233 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0a94474ea8418a62d907fc07ae8afbdc',
      'native_key' => 'OnPluginFormPrerender',
      'filename' => 'modEvent/63db60b629b08a2296d2b2816d749d94.vehicle',
    ),
    234 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '57c3ad1ea2604bea9263db873f61eb6f',
      'native_key' => 'OnPluginFormRender',
      'filename' => 'modEvent/9549e536bd2b0fd766fd3d5ce1d99859.vehicle',
    ),
    235 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f8f3452ab34523a69ca3ec0acc9aee54',
      'native_key' => 'OnBeforePluginFormSave',
      'filename' => 'modEvent/a87635b4cf938a88465f16c4219febb1.vehicle',
    ),
    236 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd04ef9e04126fa8a07eea7ae99d84113',
      'native_key' => 'OnPluginFormSave',
      'filename' => 'modEvent/08af634bb8b5957e3d6f83cc2324cdda.vehicle',
    ),
    237 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fe8657b88249621b0842ba7feaa11d9e',
      'native_key' => 'OnBeforePluginFormDelete',
      'filename' => 'modEvent/1dafacfacaa18991eecce7ada819f512.vehicle',
    ),
    238 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bdf49c9b1309173cb0e9249c61fe0f01',
      'native_key' => 'OnPluginFormDelete',
      'filename' => 'modEvent/fd4197ad7774558c2ceae779759f08cc.vehicle',
    ),
    239 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7f90941d003347e71deedaf09f47725c',
      'native_key' => 'OnPropertySetSave',
      'filename' => 'modEvent/4b11b60ceda346b9f54dc70bd1c277c6.vehicle',
    ),
    240 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e7c0419439c26e6d7fa21412c27e1f2b',
      'native_key' => 'OnPropertySetBeforeSave',
      'filename' => 'modEvent/dcb2c6e1cacf39e10cccc88937e37820.vehicle',
    ),
    241 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a58661d5c84ea4f9f6d6decce9738c33',
      'native_key' => 'OnPropertySetRemove',
      'filename' => 'modEvent/82e00f349788b52d2ffe7fd2887cbf72.vehicle',
    ),
    242 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b9d4abbee413328d7862c86026ac0f22',
      'native_key' => 'OnPropertySetBeforeRemove',
      'filename' => 'modEvent/9bb13ec2921900059bec6b6b7f1ead45.vehicle',
    ),
    243 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '02461c9f5d8423f84ba4efbf5b6c6217',
      'native_key' => 'OnMediaSourceBeforeFormDelete',
      'filename' => 'modEvent/70467a7f7b079f3b362316565c00b5a4.vehicle',
    ),
    244 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fc10186d0fcb7dd553cac1ffc23eb6e3',
      'native_key' => 'OnMediaSourceBeforeFormSave',
      'filename' => 'modEvent/990433eff244c3c7dfe434735401c164.vehicle',
    ),
    245 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '52192981ffe3de792175babaefeab5ce',
      'native_key' => 'OnMediaSourceGetProperties',
      'filename' => 'modEvent/b55c266f5ef19624da50970e4a951e76.vehicle',
    ),
    246 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0dce82606a4ee3e75322d5b7ba8a1138',
      'native_key' => 'OnMediaSourceFormDelete',
      'filename' => 'modEvent/e538eee642f3a3e34d6cece130c88912.vehicle',
    ),
    247 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '15ad3a8e99f5ef4ec2d63dcc2b8626de',
      'native_key' => 'OnMediaSourceFormSave',
      'filename' => 'modEvent/722b114321dc74774061cc33db397179.vehicle',
    ),
    248 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9a89228b562390d1d989ea8cd7f0ef8a',
      'native_key' => 'OnMediaSourceDuplicate',
      'filename' => 'modEvent/42ab3c4106cb69cee25f7471cc784a96.vehicle',
    ),
    249 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f09eefde3d065b9263ee48dbe1e88e79',
      'native_key' => 'access_category_enabled',
      'filename' => 'modSystemSetting/247a4e3ad6be20a1d985e4499a6d973a.vehicle',
    ),
    250 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '84d26161bbcc67a1949a8e73d7b83cbc',
      'native_key' => 'access_context_enabled',
      'filename' => 'modSystemSetting/548405842c3f5885f04adc2158737377.vehicle',
    ),
    251 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd82e1a50b10f159bfe158626340b1bf8',
      'native_key' => 'access_resource_group_enabled',
      'filename' => 'modSystemSetting/d52542079c956bb73339e57f5fc59e6a.vehicle',
    ),
    252 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f944603de70f506a046ce417d7dba06c',
      'native_key' => 'allow_forward_across_contexts',
      'filename' => 'modSystemSetting/daf5b02f44ba99d574189fed0dbcc775.vehicle',
    ),
    253 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7bf57f504ac4c68e1388aafad66e59fb',
      'native_key' => 'allow_manager_login_forgot_password',
      'filename' => 'modSystemSetting/715fe92fee39fab4de6c32d9f93e9e90.vehicle',
    ),
    254 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd80224faec45bdec4a3f7e3c106c8330',
      'native_key' => 'allow_multiple_emails',
      'filename' => 'modSystemSetting/a40da9d48ddef0ea57abe8212796a17d.vehicle',
    ),
    255 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e788b068f13bbb5aa6501e3e1b4368aa',
      'native_key' => 'allow_tags_in_post',
      'filename' => 'modSystemSetting/4585297be44f96554473322f20761c0b.vehicle',
    ),
    256 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8cbdacd98f9b5ec5e186e16af35edf08',
      'native_key' => 'archive_with',
      'filename' => 'modSystemSetting/e9b9daf0e3f7c3aaae210582b1d780ce.vehicle',
    ),
    257 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2930b17b093d7e8a4c8a98ac64b1a128',
      'native_key' => 'auto_menuindex',
      'filename' => 'modSystemSetting/cba5c9d24fdd676db8eec809d9aabe9c.vehicle',
    ),
    258 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4025a2f1aacb3950fe9c0f8af0f50dc2',
      'native_key' => 'auto_check_pkg_updates',
      'filename' => 'modSystemSetting/76d276ffa8e2b801480e2d02f3a4f5f3.vehicle',
    ),
    259 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6f047bff96fee8c89a183a4a0c8f7be3',
      'native_key' => 'auto_check_pkg_updates_cache_expire',
      'filename' => 'modSystemSetting/3acacc127f78416b419b06a1ad2e0e57.vehicle',
    ),
    260 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f1dde605f057bd7499bd5e2daca96398',
      'native_key' => 'automatic_alias',
      'filename' => 'modSystemSetting/cb570ab5d212138b105f62bd08bd30ff.vehicle',
    ),
    261 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4739a83d005ca13c56b585d0dc36f142',
      'native_key' => 'base_help_url',
      'filename' => 'modSystemSetting/ed677e9cfd65d0409382e32221555618.vehicle',
    ),
    262 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fc74059a1ad2817d6c9dd10d9ad9e58f',
      'native_key' => 'blocked_minutes',
      'filename' => 'modSystemSetting/7a17a5126173c2c784b2ad7e5bb9762d.vehicle',
    ),
    263 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2e6a48f2d0574eaa74cbb59f11296673',
      'native_key' => 'cache_action_map',
      'filename' => 'modSystemSetting/a557887afb99e4cf9b0196e0aad4517a.vehicle',
    ),
    264 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5c82973d1efaf88ea7f2c53b26e39818',
      'native_key' => 'cache_alias_map',
      'filename' => 'modSystemSetting/c8ebf5dbbac7f847620e7becab357171.vehicle',
    ),
    265 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1168eeab8d9aa130b2b6b90083002105',
      'native_key' => 'cache_context_settings',
      'filename' => 'modSystemSetting/6a2b1e09cfe57394a4d6f3c83571907d.vehicle',
    ),
    266 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '554f8fc5bef62cb41923c79a0e667e37',
      'native_key' => 'cache_db',
      'filename' => 'modSystemSetting/415151235b6c266529303512c3fb6e37.vehicle',
    ),
    267 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a04c5a366efd878bddb1f1999f85831a',
      'native_key' => 'cache_db_expires',
      'filename' => 'modSystemSetting/4c351ce68468c464ca92e8a362e9cd71.vehicle',
    ),
    268 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a69981343f3bef7b28c7f3d03afa3708',
      'native_key' => 'cache_db_session',
      'filename' => 'modSystemSetting/9d336347c8153987ec5f4381551f8966.vehicle',
    ),
    269 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '72a5b9f56692de753d0ea91bb117540b',
      'native_key' => 'cache_db_session_lifetime',
      'filename' => 'modSystemSetting/51752a88961c3b5e278fbd12b5b07b63.vehicle',
    ),
    270 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '96a0ab16bd859d23b77535906c5f5c41',
      'native_key' => 'cache_default',
      'filename' => 'modSystemSetting/b2180930c005581a2d70a3e0a8bbb5c5.vehicle',
    ),
    271 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5f9761ef2d6b87acc7149b374d3fee48',
      'native_key' => 'cache_disabled',
      'filename' => 'modSystemSetting/2a483078ac6b472dd5ebd6b7f3ca924e.vehicle',
    ),
    272 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c2e98005b2ea2ad0e05b377d4708b21d',
      'native_key' => 'cache_expires',
      'filename' => 'modSystemSetting/8d8c6a8f7a35b671ea4a5941c1df5616.vehicle',
    ),
    273 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b254081023a2f1e07a38f8c1a5409729',
      'native_key' => 'cache_format',
      'filename' => 'modSystemSetting/a9753811ea389fa44c2c23bad5196ad8.vehicle',
    ),
    274 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a1e755948eb32f163d7cef9a0b27457c',
      'native_key' => 'cache_handler',
      'filename' => 'modSystemSetting/ec3737e7cf3188e2237f23bb11a6f986.vehicle',
    ),
    275 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f80e371be201b1fde818d5879ea6bafc',
      'native_key' => 'cache_lang_js',
      'filename' => 'modSystemSetting/d6acf3e8c18eb9b1b9b9670f1c3d53bd.vehicle',
    ),
    276 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b8e00bc30071c352f334dc64c60a5072',
      'native_key' => 'cache_lexicon_topics',
      'filename' => 'modSystemSetting/70ae028b2dea9d467127e163d95f4ebb.vehicle',
    ),
    277 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e420eba091b3691da07a74c248d48214',
      'native_key' => 'cache_noncore_lexicon_topics',
      'filename' => 'modSystemSetting/cef54761cc4d764ee3d2a2ce70682861.vehicle',
    ),
    278 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '28045f1545cd712305c2b12dbf75880c',
      'native_key' => 'cache_resource',
      'filename' => 'modSystemSetting/93845490ee1a27e0e2c128bfab72777c.vehicle',
    ),
    279 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '36a51127b6a1244aed2cfe4dfb7e07f4',
      'native_key' => 'cache_resource_expires',
      'filename' => 'modSystemSetting/1d289e10069f6b649d67c61398c91bf0.vehicle',
    ),
    280 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c5510062cb56f96ee54228d4eea17853',
      'native_key' => 'cache_scripts',
      'filename' => 'modSystemSetting/decbfe8b417312ba659078132bb5ff75.vehicle',
    ),
    281 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cb357fdcf43ff6d5e0e76bd57955679c',
      'native_key' => 'cache_system_settings',
      'filename' => 'modSystemSetting/ff81ace3d1d667cdb67fd82414a8c565.vehicle',
    ),
    282 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '50ae0a33b907e00e016641856bbd1c89',
      'native_key' => 'clear_cache_refresh_trees',
      'filename' => 'modSystemSetting/73c688ceb9c7bf9e31e9f74f66fc7836.vehicle',
    ),
    283 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c9fa22c507541327887e16458eb75067',
      'native_key' => 'compress_css',
      'filename' => 'modSystemSetting/f4bf4411c3fd53e2ec9e3bc8a2bfcda7.vehicle',
    ),
    284 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0ea00cee1b92b24736ec48fcab0464c0',
      'native_key' => 'compress_js',
      'filename' => 'modSystemSetting/a9edc0e33b1a0fa93f2c3056e473379e.vehicle',
    ),
    285 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7480a4b7651de07d99e975fa21c22ff5',
      'native_key' => 'compress_js_max_files',
      'filename' => 'modSystemSetting/b189033b54074f06b2b6c48e7ed455cc.vehicle',
    ),
    286 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '96799f6ddcb580d0bf422ce6c1f0eb8c',
      'native_key' => 'compress_js_groups',
      'filename' => 'modSystemSetting/409334fa998d1bcc1629f0875e830c44.vehicle',
    ),
    287 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'efe773fb717ee130b404cf02ab639bca',
      'native_key' => 'container_suffix',
      'filename' => 'modSystemSetting/b64a0f20028d5a88ae425024ca05a0f8.vehicle',
    ),
    288 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f7b04928cd5e076d346f3dc788f88676',
      'native_key' => 'context_tree_sort',
      'filename' => 'modSystemSetting/e331768e0deb57979829a8e4034416db.vehicle',
    ),
    289 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0b9bf29df9a17c9ef8a2eb4db73cb1fc',
      'native_key' => 'context_tree_sortby',
      'filename' => 'modSystemSetting/b27a2ccce156ed0ef405efcfec935049.vehicle',
    ),
    290 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'be858d27ffd30ce382d128f30bfb6b64',
      'native_key' => 'context_tree_sortdir',
      'filename' => 'modSystemSetting/986457cea1384b607fbffe402a95d69e.vehicle',
    ),
    291 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3693fb3b9e8e5f23a755482809e40b99',
      'native_key' => 'cultureKey',
      'filename' => 'modSystemSetting/a022714ac6dc89957a276015167d3f5a.vehicle',
    ),
    292 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '874b90747e3cbcdc5cbc243c98a3cb79',
      'native_key' => 'date_timezone',
      'filename' => 'modSystemSetting/8e52a525be4c03a19882e2c1c01f5e45.vehicle',
    ),
    293 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c625e619bde5d3460336d403d7ef07b5',
      'native_key' => 'debug',
      'filename' => 'modSystemSetting/e589568448973508ac36e568639eb09d.vehicle',
    ),
    294 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '242f648c7ee1b7bb98b29ba0ed00d775',
      'native_key' => 'default_duplicate_publish_option',
      'filename' => 'modSystemSetting/b5e3c4d1cc894f13d1132058795c31e6.vehicle',
    ),
    295 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd2581299a62ca689d4066b060c67da9b',
      'native_key' => 'default_media_source',
      'filename' => 'modSystemSetting/fad56739f7e58b1abdf6256f3c9c23e3.vehicle',
    ),
    296 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9a39cd8410a1617ada602701d2d761eb',
      'native_key' => 'default_per_page',
      'filename' => 'modSystemSetting/69691e741a775cec0eea2aedc9fc950e.vehicle',
    ),
    297 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b542f0bd6dbe39435135e218ff8d3e80',
      'native_key' => 'default_context',
      'filename' => 'modSystemSetting/c707b3f1ecdd9521d8394c1d0bc1d50f.vehicle',
    ),
    298 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '97ff47c3979e686091eafe0f70bd157d',
      'native_key' => 'default_template',
      'filename' => 'modSystemSetting/c5dcf961c26ed1c78c3415c534b3b5cb.vehicle',
    ),
    299 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b86f55fd4072283a83b7772372e7b738',
      'native_key' => 'default_content_type',
      'filename' => 'modSystemSetting/bd4f7aa2762131f1407c35546f138ab3.vehicle',
    ),
    300 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5f654b2c076b55408c1ff53c031a24e7',
      'native_key' => 'editor_css_path',
      'filename' => 'modSystemSetting/33003a0d8511abb6d0aa02767baf3e42.vehicle',
    ),
    301 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'aa72687a103bfdda3ab2c19784dab896',
      'native_key' => 'editor_css_selectors',
      'filename' => 'modSystemSetting/9af7e2d50cf398b8d6ae641c6c26977a.vehicle',
    ),
    302 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8541c96a6f9ff000593ef922bf0aa2f7',
      'native_key' => 'emailsender',
      'filename' => 'modSystemSetting/6944c9257e0747efa7334118b75491d2.vehicle',
    ),
    303 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3d3eb337725e0d129214a3d771629aac',
      'native_key' => 'emailsubject',
      'filename' => 'modSystemSetting/921271714bc10e43761d1b9c61db47be.vehicle',
    ),
    304 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '87096d2d58ed1247708eba1305b831ba',
      'native_key' => 'enable_dragdrop',
      'filename' => 'modSystemSetting/3985e12293dcf946a9300ba9496df90e.vehicle',
    ),
    305 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'de083960b5cd0bf791b8ab0267ad625e',
      'native_key' => 'error_page',
      'filename' => 'modSystemSetting/d66d4c9d02c904f355d53d4675a31819.vehicle',
    ),
    306 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5eed8c32de88b9228e50a2cf4bb833fd',
      'native_key' => 'failed_login_attempts',
      'filename' => 'modSystemSetting/d1f64e4b8f8daa6605e1a1f1eb582c72.vehicle',
    ),
    307 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '685a8142660219eb5e0830aefa8a2a72',
      'native_key' => 'fe_editor_lang',
      'filename' => 'modSystemSetting/788d1fc73bb7a903f1eb14aea8cdb3f3.vehicle',
    ),
    308 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4532a3ed7ae1b399caa1c51dcfc3641b',
      'native_key' => 'feed_modx_news',
      'filename' => 'modSystemSetting/b25fd2ac903c242c35167c31fae8a65e.vehicle',
    ),
    309 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1e68962c8207de04f946d27f9a90e30e',
      'native_key' => 'feed_modx_news_enabled',
      'filename' => 'modSystemSetting/4bba690d4002d7036db15f5710da920c.vehicle',
    ),
    310 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fc1c2c4fafc9d8f759ecc535f4f226c3',
      'native_key' => 'feed_modx_security',
      'filename' => 'modSystemSetting/9e4178da7ad52a9a666f2d7bf165cef4.vehicle',
    ),
    311 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e51e44ad049c1045dd995793b806e6aa',
      'native_key' => 'feed_modx_security_enabled',
      'filename' => 'modSystemSetting/c7b836a2f0030e01fb4fad1cf98974c9.vehicle',
    ),
    312 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ca3e620a1d890dbbcbe17ee61477c856',
      'native_key' => 'filemanager_path',
      'filename' => 'modSystemSetting/2164feeab39739d1df2704796f2262d4.vehicle',
    ),
    313 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a4d60c3cc1dffec41203655420a48c07',
      'native_key' => 'filemanager_path_relative',
      'filename' => 'modSystemSetting/e36a08e72ddea169bf54ba3636018d02.vehicle',
    ),
    314 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '95bec8868d7de144d303e9c5bfc718b1',
      'native_key' => 'filemanager_url',
      'filename' => 'modSystemSetting/d5019e48cee2db055f6ac4d826bb6186.vehicle',
    ),
    315 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '83d59b69a7e988f10a86fe65c2b73161',
      'native_key' => 'filemanager_url_relative',
      'filename' => 'modSystemSetting/b8ac93fd72295695a23dbb40c7901dc9.vehicle',
    ),
    316 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ec819dea466aa84bf7d187598ef0bdca',
      'native_key' => 'forgot_login_email',
      'filename' => 'modSystemSetting/b37ac6e694c42b366c495912014a7024.vehicle',
    ),
    317 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3894acd9352e0fc664681b971c5ef1d5',
      'native_key' => 'form_customization_use_all_groups',
      'filename' => 'modSystemSetting/b68527df6d3c9d60af2d46e0249ef19c.vehicle',
    ),
    318 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fdfe1bc7b5797d033e9f076b7e314682',
      'native_key' => 'forward_merge_excludes',
      'filename' => 'modSystemSetting/1458eded173b4d8ad26b2afaf8c2e165.vehicle',
    ),
    319 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cd92c3b2562deb1fcb541c96ed1757b8',
      'native_key' => 'friendly_alias_lowercase_only',
      'filename' => 'modSystemSetting/5f25b1ed25096182676531aa325ac8a2.vehicle',
    ),
    320 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ffae45fc50cf48d0b16b5c67a8492e58',
      'native_key' => 'friendly_alias_max_length',
      'filename' => 'modSystemSetting/9b88d99231bb2c8b9dcf33a1e005ce6a.vehicle',
    ),
    321 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0ca834400b96b99d43b4666e311cdda9',
      'native_key' => 'friendly_alias_restrict_chars',
      'filename' => 'modSystemSetting/5d7f54831d390bc9b220a3c347934c17.vehicle',
    ),
    322 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a015198de5fdf78c267a8d0de9d68316',
      'native_key' => 'friendly_alias_restrict_chars_pattern',
      'filename' => 'modSystemSetting/48cadf34954074dddb2a0dce89465692.vehicle',
    ),
    323 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fa1f41dcd75ba9c62ae00963b78d7454',
      'native_key' => 'friendly_alias_strip_element_tags',
      'filename' => 'modSystemSetting/83d2d866c913119ad95d8b31a8778303.vehicle',
    ),
    324 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '926c34b0a222242201424649773e4cfc',
      'native_key' => 'friendly_alias_translit',
      'filename' => 'modSystemSetting/ba1b68938c0288e6b0aaa9578e81d2c3.vehicle',
    ),
    325 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'edd53dcebaf1effd6699ea6b3dda0d5e',
      'native_key' => 'friendly_alias_translit_class',
      'filename' => 'modSystemSetting/e4f0afcc46ea43c81580c9f5e97803dd.vehicle',
    ),
    326 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd8d76431d96067bcda13457684a0f2bc',
      'native_key' => 'friendly_alias_translit_class_path',
      'filename' => 'modSystemSetting/3d416ae61066d075435ded35fcd5efb3.vehicle',
    ),
    327 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5efa4023639636a655ae5dbdd6677bcd',
      'native_key' => 'friendly_alias_trim_chars',
      'filename' => 'modSystemSetting/5f798d29bd149fef1de575fda450072a.vehicle',
    ),
    328 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'af8062a45da9f134cbaad5ad750f5621',
      'native_key' => 'friendly_alias_word_delimiter',
      'filename' => 'modSystemSetting/38590297b841f889f0e84d7263cf0796.vehicle',
    ),
    329 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c27568ee10dd5a3a107666c9bbfac287',
      'native_key' => 'friendly_alias_word_delimiters',
      'filename' => 'modSystemSetting/30769b7c8dd08aab9194623b785aa3bb.vehicle',
    ),
    330 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6ad351676406d69b815382e476ce76e1',
      'native_key' => 'friendly_urls',
      'filename' => 'modSystemSetting/096429839128ef564bd99ef8f5793d48.vehicle',
    ),
    331 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4e5ba6c718a66fb8f008d80305fc788a',
      'native_key' => 'friendly_urls_strict',
      'filename' => 'modSystemSetting/32452f18f08c5de552f15b5072ab967a.vehicle',
    ),
    332 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7430039fb835ccd136ec20eda6dad0e1',
      'native_key' => 'global_duplicate_uri_check',
      'filename' => 'modSystemSetting/b588cce0d4c3d44104486a0087b4f9f6.vehicle',
    ),
    333 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '76038cdcfbf93101920313c10784a247',
      'native_key' => 'hidemenu_default',
      'filename' => 'modSystemSetting/7a26a89baabcda91c0f080e82fc11c2c.vehicle',
    ),
    334 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fc815117dd6ead12c6307b9525a011c1',
      'native_key' => 'inline_help',
      'filename' => 'modSystemSetting/1d7fc9936e8c99c4c9282511e3590288.vehicle',
    ),
    335 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ba03f431b3cb86a190afafdf55df19bc',
      'native_key' => 'locale',
      'filename' => 'modSystemSetting/0a32a57d7d0cc25793848b13bc8cbe87.vehicle',
    ),
    336 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1b0e9b1dbd7cb5f40499b750f3a4f5bf',
      'native_key' => 'log_level',
      'filename' => 'modSystemSetting/32477f819bd2cf5012737b99b4c77c96.vehicle',
    ),
    337 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a5c45ee62d69d41b2e325ea5957f41d9',
      'native_key' => 'log_target',
      'filename' => 'modSystemSetting/d7640c6306f2116bb88026f908e9c320.vehicle',
    ),
    338 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ff022cc7e1a4e1cc2b17b8374d8c1d88',
      'native_key' => 'link_tag_scheme',
      'filename' => 'modSystemSetting/c79dd039d4809561f61100e27ed2a356.vehicle',
    ),
    339 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '466a18c1e133651d1cf2ac5afc25ebbd',
      'native_key' => 'lock_ttl',
      'filename' => 'modSystemSetting/637d4613676ff9b18702ce4e39c0ee0f.vehicle',
    ),
    340 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3f990ccd32d99eff9bd2e263525adb0a',
      'native_key' => 'mail_charset',
      'filename' => 'modSystemSetting/47e27f77267b85c0f5294d0615dd73fb.vehicle',
    ),
    341 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6a36ac0912b939b0902ca2c3ca5012bc',
      'native_key' => 'mail_encoding',
      'filename' => 'modSystemSetting/21168e2ddf697702d152981989700230.vehicle',
    ),
    342 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7595282dc3f1e7e60e4f8165e0316cc9',
      'native_key' => 'mail_use_smtp',
      'filename' => 'modSystemSetting/5a2cb0151a4c866b69a238864547fbc0.vehicle',
    ),
    343 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e6367804fb2dc6ced5795456b67640e3',
      'native_key' => 'mail_smtp_auth',
      'filename' => 'modSystemSetting/385b696800114a3a3708334a0ed5183e.vehicle',
    ),
    344 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '228b1f92eef7514b6359472b2a100a42',
      'native_key' => 'mail_smtp_helo',
      'filename' => 'modSystemSetting/83afbc087462336039a4b1b8dbc4863c.vehicle',
    ),
    345 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6330d9bbd62e08b868bc135d49441a8b',
      'native_key' => 'mail_smtp_hosts',
      'filename' => 'modSystemSetting/76aa2e1c9e2b46c6e5e3b514a667439c.vehicle',
    ),
    346 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c77ca7543b39ce44d54c3561bc308c11',
      'native_key' => 'mail_smtp_keepalive',
      'filename' => 'modSystemSetting/27e1dea706f1639b0353d8e3069231ab.vehicle',
    ),
    347 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '020eb98f69330a297460760cdf1a5fd3',
      'native_key' => 'mail_smtp_pass',
      'filename' => 'modSystemSetting/44ec9c7d7d352138c72e897dfdb235ab.vehicle',
    ),
    348 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5e336ae1241e4b24235b9998d6c83f62',
      'native_key' => 'mail_smtp_port',
      'filename' => 'modSystemSetting/16aaaea117d4411415609c60d6dc8580.vehicle',
    ),
    349 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3a8155dbc463b5a97b4dda651046ad7c',
      'native_key' => 'mail_smtp_prefix',
      'filename' => 'modSystemSetting/cc8cf6b7dbd944a4645c41df5ea0cc65.vehicle',
    ),
    350 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7b5f451ce2d19bdd1b248f8a4dd1bc8b',
      'native_key' => 'mail_smtp_single_to',
      'filename' => 'modSystemSetting/79ebd201fe430fad0bdac8d8611e2baf.vehicle',
    ),
    351 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b9ecfcab6694466cca01cfc28fa424b9',
      'native_key' => 'mail_smtp_timeout',
      'filename' => 'modSystemSetting/dc8dcf72785a25d067595f884dc1167f.vehicle',
    ),
    352 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b575d128a6058f277f9dc1a4f4f3d9ef',
      'native_key' => 'mail_smtp_user',
      'filename' => 'modSystemSetting/829184bb945e6faa92bc158a4270c840.vehicle',
    ),
    353 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5dfee9841feea3b5c2b9862882e5f789',
      'native_key' => 'manager_date_format',
      'filename' => 'modSystemSetting/c628459ab9361227db01b28adfb9dc27.vehicle',
    ),
    354 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '81401b903eefbbe191e8d076bf9cf4e1',
      'native_key' => 'manager_favicon_url',
      'filename' => 'modSystemSetting/a46f7ef4cbddd688d43b7e9fef99266c.vehicle',
    ),
    355 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3a493aa18c04ac6d01130dd50b104e94',
      'native_key' => 'manager_html5_cache',
      'filename' => 'modSystemSetting/60adfb111672abba098ff1e18878eac2.vehicle',
    ),
    356 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8878e0f43bf71a347d88ad7044fb0589',
      'native_key' => 'manager_js_cache_file_locking',
      'filename' => 'modSystemSetting/845d94254b080886318bfa50de151f35.vehicle',
    ),
    357 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '196d97f86d277ac888cc0fa651b75341',
      'native_key' => 'manager_js_cache_max_age',
      'filename' => 'modSystemSetting/f18aae7e60b2017f2cc436d5b8691422.vehicle',
    ),
    358 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b6eaa05b066a086f7e37ce09a2359997',
      'native_key' => 'manager_js_document_root',
      'filename' => 'modSystemSetting/31bab5bc127c99f35605ec7af100e356.vehicle',
    ),
    359 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '34afd9ad9731ee3f10e7fed48f2d53a3',
      'native_key' => 'manager_js_zlib_output_compression',
      'filename' => 'modSystemSetting/d21e25dc13d9dea1e89433afee7f363f.vehicle',
    ),
    360 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dc1fc8f812f234c898a7b896c0d706ce',
      'native_key' => 'manager_time_format',
      'filename' => 'modSystemSetting/96fa1edd84463493151c376d4de68c0a.vehicle',
    ),
    361 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b6dfc4cfe17ac77406a1832b0989a635',
      'native_key' => 'manager_direction',
      'filename' => 'modSystemSetting/df973c35b684628c627fec66d8707186.vehicle',
    ),
    362 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '72ad6f2866745d94df9865d81f75bd62',
      'native_key' => 'manager_lang_attribute',
      'filename' => 'modSystemSetting/45a5aa0c947e5f16dc3b0dd1b27e1bf5.vehicle',
    ),
    363 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3f3d826d17449078bfbdcdf9076991fb',
      'native_key' => 'manager_language',
      'filename' => 'modSystemSetting/0875f322477998208b6c9e934d90bd89.vehicle',
    ),
    364 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '030d03354d6c51b196867e59f93941e0',
      'native_key' => 'manager_login_url_alternate',
      'filename' => 'modSystemSetting/6cd8b71b2add3beb0c4da955bcc8523d.vehicle',
    ),
    365 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c03283dba00a3dd1b48f666bcc2b2a5f',
      'native_key' => 'manager_theme',
      'filename' => 'modSystemSetting/8ad6baac2db6c91c5282b2c0118c6c4b.vehicle',
    ),
    366 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e90209f8eb0a4345a5d21cfd8a6bab28',
      'native_key' => 'manager_week_start',
      'filename' => 'modSystemSetting/f887dbf8e7ef18731de13d3af8992a53.vehicle',
    ),
    367 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0953d5be6d75fb07206ae9e354b88c59',
      'native_key' => 'modx_browser_default_sort',
      'filename' => 'modSystemSetting/d2a110f5b4ae5d48f66dd7bb32c8594f.vehicle',
    ),
    368 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a4b19d034efb52f49c13ef8b45e99013',
      'native_key' => 'modx_charset',
      'filename' => 'modSystemSetting/593df13e1576a1f57ea0f469eed9985e.vehicle',
    ),
    369 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3e1f70fd5411a4031730a9f7024b7a7e',
      'native_key' => 'principal_targets',
      'filename' => 'modSystemSetting/e3c4eaadf1971ab6c1e21c9960098c41.vehicle',
    ),
    370 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'afd48df1206b2b0500cc790193bfa732',
      'native_key' => 'proxy_auth_type',
      'filename' => 'modSystemSetting/48b0e0e06ba5777145cd503f44010652.vehicle',
    ),
    371 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b7735f250014577974399b6e3902d029',
      'native_key' => 'proxy_host',
      'filename' => 'modSystemSetting/5e59632f395ff78cd45ddd93465795d8.vehicle',
    ),
    372 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f07c4977f766eaa7230d6d865825227e',
      'native_key' => 'proxy_password',
      'filename' => 'modSystemSetting/5c73cb329de4ce6df7fd66064ad38ad6.vehicle',
    ),
    373 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '706a92edb3d835326fae8871b58ced39',
      'native_key' => 'proxy_port',
      'filename' => 'modSystemSetting/84d120924e5645d179fceb504d2bf2fb.vehicle',
    ),
    374 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c52de5e15b1724448a09c0f1ad6c82ea',
      'native_key' => 'proxy_username',
      'filename' => 'modSystemSetting/ebad4371f597435bf8111814665fbc3d.vehicle',
    ),
    375 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '75a12d640af21018daa7604e19c607a0',
      'native_key' => 'password_generated_length',
      'filename' => 'modSystemSetting/900a14d6b70b646e3d1a47f84cda074c.vehicle',
    ),
    376 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '23712f321d1e17b9db2632116092a9d5',
      'native_key' => 'password_min_length',
      'filename' => 'modSystemSetting/5084abde2d5e91f8b86e6f8719e2222c.vehicle',
    ),
    377 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0568171433f7f1e75b2b2cc68872e386',
      'native_key' => 'phpthumb_allow_src_above_docroot',
      'filename' => 'modSystemSetting/18ecedecf50bd8ee8ef4072e3e381d3b.vehicle',
    ),
    378 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '53190ff48021adc94ee15801b155449e',
      'native_key' => 'phpthumb_cache_maxage',
      'filename' => 'modSystemSetting/771f264292478ad2e395debf9009c149.vehicle',
    ),
    379 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c3ed88c240579d2c23f2b20ea6617125',
      'native_key' => 'phpthumb_cache_maxsize',
      'filename' => 'modSystemSetting/3f06599ab29b5107c709dea42a99871d.vehicle',
    ),
    380 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '989d1da666333a1bdd7be9af937f057f',
      'native_key' => 'phpthumb_cache_maxfiles',
      'filename' => 'modSystemSetting/7a931e88c00695ca3bee7f093b698a9c.vehicle',
    ),
    381 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a6d6a7c63bd7ff2457bce33038d4472d',
      'native_key' => 'phpthumb_cache_source_enabled',
      'filename' => 'modSystemSetting/d73eee44af36a40a206d2223c726cd5d.vehicle',
    ),
    382 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8f0163d1efbefc0eb84497950e73d7ae',
      'native_key' => 'phpthumb_document_root',
      'filename' => 'modSystemSetting/4faf839a9a53732742d95b8411f1d233.vehicle',
    ),
    383 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '72aab493965aa8c7ff58d5a4763eacd0',
      'native_key' => 'phpthumb_error_bgcolor',
      'filename' => 'modSystemSetting/8597f0b4628e7705fc39703778267d71.vehicle',
    ),
    384 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3511776cffe5f5cf39f78f4fcf22a7fa',
      'native_key' => 'phpthumb_error_textcolor',
      'filename' => 'modSystemSetting/0df0b56c2eb372c1cb6418670853398d.vehicle',
    ),
    385 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '616077728f9451616b473e0206b98ea0',
      'native_key' => 'phpthumb_error_fontsize',
      'filename' => 'modSystemSetting/fa11f189226d7311a3208fd78ad80185.vehicle',
    ),
    386 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bf05123f32457747b845f7aea1a540cf',
      'native_key' => 'phpthumb_far',
      'filename' => 'modSystemSetting/8b9e6a49835a2f2af4216dc4dca4c2ad.vehicle',
    ),
    387 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c9d784bf0a46504da013ac0eb0e9a069',
      'native_key' => 'phpthumb_imagemagick_path',
      'filename' => 'modSystemSetting/bed9f9912348940cb9cf33c0d805bedd.vehicle',
    ),
    388 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '234dbd088520608187c691562fa6f140',
      'native_key' => 'phpthumb_nohotlink_enabled',
      'filename' => 'modSystemSetting/77154e36bd9aa8626f42707161c004c8.vehicle',
    ),
    389 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f59ae5bf2185e6dcb4f1f43673e6e5a8',
      'native_key' => 'phpthumb_nohotlink_erase_image',
      'filename' => 'modSystemSetting/b5e39b46854377540deb5b0014e79650.vehicle',
    ),
    390 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '773fd45c1dea31057ae8332b9a4dc2b4',
      'native_key' => 'phpthumb_nohotlink_valid_domains',
      'filename' => 'modSystemSetting/8288815bbc657f3e61be6d30bed0efbb.vehicle',
    ),
    391 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e6d2b1d68216e6d071fc9c63085abfa7',
      'native_key' => 'phpthumb_nohotlink_text_message',
      'filename' => 'modSystemSetting/671188a3979db3b77f232dde54831afb.vehicle',
    ),
    392 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f6c496b10fca6228bfd3ee91bafc30a5',
      'native_key' => 'phpthumb_nooffsitelink_enabled',
      'filename' => 'modSystemSetting/7c772f0fff4bc7a0f8208d52b3960caa.vehicle',
    ),
    393 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bcbb207d50539cc16cc48f8f7b053613',
      'native_key' => 'phpthumb_nooffsitelink_erase_image',
      'filename' => 'modSystemSetting/c0097867c605032a7b70ed668c4074ec.vehicle',
    ),
    394 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2b58b2aef356a32ed8c6573bf6bc4a0a',
      'native_key' => 'phpthumb_nooffsitelink_require_refer',
      'filename' => 'modSystemSetting/a07a8df06fb0fe7090352d58a13d4fab.vehicle',
    ),
    395 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dfb09a2b6a5c8066a3e50736ed03917d',
      'native_key' => 'phpthumb_nooffsitelink_text_message',
      'filename' => 'modSystemSetting/7e3eb044a99eca85c5a08aed34a22bbc.vehicle',
    ),
    396 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '53deede8dde03706982407e595bd142b',
      'native_key' => 'phpthumb_nooffsitelink_valid_domains',
      'filename' => 'modSystemSetting/fa5b42720c0f17dfa8ede6b33f1ccc84.vehicle',
    ),
    397 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd59d89810d28ad64cea0fcfdfa7bd171',
      'native_key' => 'phpthumb_nooffsitelink_watermark_src',
      'filename' => 'modSystemSetting/a9b7883f6cd7039d41ff1930f2d9e57e.vehicle',
    ),
    398 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c5e8c329575ef00d9c7bb4e1a03360ff',
      'native_key' => 'phpthumb_zoomcrop',
      'filename' => 'modSystemSetting/f1ea4fb8e2730971e98e900c7d24e98b.vehicle',
    ),
    399 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9c375abd8b9d088e2f58ec2a680be2ed',
      'native_key' => 'publish_default',
      'filename' => 'modSystemSetting/8bf70ee38d0482dd2feb25dbecf655c9.vehicle',
    ),
    400 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e783f91b11016f4454906c049404c530',
      'native_key' => 'rb_base_dir',
      'filename' => 'modSystemSetting/91c65a90ac47b733bda98e53ae8c2fbf.vehicle',
    ),
    401 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '574fe9f9102304312595b5867ff93d78',
      'native_key' => 'rb_base_url',
      'filename' => 'modSystemSetting/56d9c842466049e9cd4605bec83b9958.vehicle',
    ),
    402 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '060db6de6df210264543efe812375b49',
      'native_key' => 'request_controller',
      'filename' => 'modSystemSetting/2a8d753b8ae5f97aba8f29d06e7b0636.vehicle',
    ),
    403 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b248519c72b3a9bd36320c7ab0fcb625',
      'native_key' => 'request_method_strict',
      'filename' => 'modSystemSetting/e32eef2cc30e2999e3fda925e06446b1.vehicle',
    ),
    404 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ca0c3d1d785958c72825878b4b074222',
      'native_key' => 'request_param_alias',
      'filename' => 'modSystemSetting/c86b4ba72c59026ffad42b3f43be1559.vehicle',
    ),
    405 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd8f3328938a648608080f8ad0be376bd',
      'native_key' => 'request_param_id',
      'filename' => 'modSystemSetting/1202d42adba65a02c05082f9dd83c0be.vehicle',
    ),
    406 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1ef20ba2fa5d05432ebc2db23ca39ef9',
      'native_key' => 'resolve_hostnames',
      'filename' => 'modSystemSetting/3439bbf87089ec86859b1ec648792257.vehicle',
    ),
    407 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '19983b491c796cb511d82f09d03c3e07',
      'native_key' => 'resource_tree_node_name',
      'filename' => 'modSystemSetting/35ee3c6175289092ddd4badaf38ad8f9.vehicle',
    ),
    408 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '77901c96e6807d75fccb9a1059f56144',
      'native_key' => 'resource_tree_node_tooltip',
      'filename' => 'modSystemSetting/82e9372f93b6b90128b0e5e86b9e9707.vehicle',
    ),
    409 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '02118a8827bf84b2e4c6f18b8b9d22cc',
      'native_key' => 'richtext_default',
      'filename' => 'modSystemSetting/7f45392c633b002924f02e507efdf569.vehicle',
    ),
    410 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '670c9a95fa8bccb65c99d7416ecda885',
      'native_key' => 'search_default',
      'filename' => 'modSystemSetting/5d967b8766f5cdeed370432cc5c369b7.vehicle',
    ),
    411 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fdef6f00d6bbbd6dbd22fea2fd1ea764',
      'native_key' => 'server_offset_time',
      'filename' => 'modSystemSetting/3a8a87f8120578ed4f0637af9e3d1a6c.vehicle',
    ),
    412 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '980072ba8c7e1988a73247bd1d871f18',
      'native_key' => 'server_protocol',
      'filename' => 'modSystemSetting/2449d1bdd61abde4114ebed0d000a4d0.vehicle',
    ),
    413 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2700f3c342184b684498ac62da74f3a7',
      'native_key' => 'session_cookie_domain',
      'filename' => 'modSystemSetting/118bab818622afae6a64f85d400c7d7b.vehicle',
    ),
    414 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7c37c939e0ac8afdbbbcd404563f17d8',
      'native_key' => 'session_cookie_lifetime',
      'filename' => 'modSystemSetting/9c889e960d1bcf42674c15178ef4c0ee.vehicle',
    ),
    415 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0a5f7e84fb8c3af43308d4e5a2952922',
      'native_key' => 'session_cookie_path',
      'filename' => 'modSystemSetting/bdc1edee431d353712e46d40ff0003c0.vehicle',
    ),
    416 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '365e1153017dc0ec18c5b8a2f110fc8a',
      'native_key' => 'session_cookie_secure',
      'filename' => 'modSystemSetting/cabaa432d79aad92c43bb6aacf9b9f73.vehicle',
    ),
    417 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0bb2e08ae0691f53c9f3f90bca89de3c',
      'native_key' => 'session_cookie_httponly',
      'filename' => 'modSystemSetting/6e42a2165328d1f5a87b10e952e4220e.vehicle',
    ),
    418 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fecf7b9af6dd814bb2c257b0583f5900',
      'native_key' => 'session_gc_maxlifetime',
      'filename' => 'modSystemSetting/df8a4c6ec312eeb24705b2a6468d3df1.vehicle',
    ),
    419 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bea2275202499239506d2804feb6726c',
      'native_key' => 'session_handler_class',
      'filename' => 'modSystemSetting/28a709f75e800a447c95c248d3ce1ddc.vehicle',
    ),
    420 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3deeef98bd9e677e581ae7c00fa791a9',
      'native_key' => 'session_name',
      'filename' => 'modSystemSetting/ce9fc39e03a476924a28d028ad1d2b33.vehicle',
    ),
    421 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7f1f19c0b32a6eaca1a5cabe069cec7c',
      'native_key' => 'set_header',
      'filename' => 'modSystemSetting/c6ee363ba05c5ea4541f53b4628d44af.vehicle',
    ),
    422 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5ec71bbb302a039b08810160d8e823a7',
      'native_key' => 'show_tv_categories_header',
      'filename' => 'modSystemSetting/a32c65cbcc7759697cac72b3cb12263e.vehicle',
    ),
    423 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '543a08eaf34850d8a12a25d611f049cd',
      'native_key' => 'signupemail_message',
      'filename' => 'modSystemSetting/4aa880c67635d465ba0332dfaab18536.vehicle',
    ),
    424 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fad4367d4e9902c3285fccd06e328fac',
      'native_key' => 'site_name',
      'filename' => 'modSystemSetting/1ae1c6430e64f576e7553a5ca07e5636.vehicle',
    ),
    425 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5def3e356ddf0c295a781be64b26bb4c',
      'native_key' => 'site_start',
      'filename' => 'modSystemSetting/cf2972f80bf86d9e27d3b8044a6db210.vehicle',
    ),
    426 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e0a21fbe31ba93fdb151a3e6bb67e3b8',
      'native_key' => 'site_status',
      'filename' => 'modSystemSetting/5c0b97275c84fd874496f6066a290641.vehicle',
    ),
    427 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd7ab222a3fa64c1a377734031255d89f',
      'native_key' => 'site_unavailable_message',
      'filename' => 'modSystemSetting/918cf3f11f4f2329c7132e216dc45f24.vehicle',
    ),
    428 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '88f2fd13e0d6de96c5f3c49b80df30bb',
      'native_key' => 'site_unavailable_page',
      'filename' => 'modSystemSetting/77f89e3718485c713a6a2e2b07e29cab.vehicle',
    ),
    429 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f0a60912d37fcbbc1c3f3772878c6650',
      'native_key' => 'strip_image_paths',
      'filename' => 'modSystemSetting/4fddddd9a6e2703b98b341ce7b045233.vehicle',
    ),
    430 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9c73b26b9f4022738b23cbd86c3c75e8',
      'native_key' => 'symlink_merge_fields',
      'filename' => 'modSystemSetting/e610ab62b7b546125c61a31f1344add9.vehicle',
    ),
    431 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6c283d08a97ff29c1e3ce97a95cfe32c',
      'native_key' => 'topmenu_show_descriptions',
      'filename' => 'modSystemSetting/3def87c5616a080a5421f73f64f70ef6.vehicle',
    ),
    432 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '550e4a785a357e377a452cdffcfdc40d',
      'native_key' => 'tree_default_sort',
      'filename' => 'modSystemSetting/3b46cb6c73ce985e74e2b876b8b41b91.vehicle',
    ),
    433 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '61fc1bb580f9272dfeabcbbcf686def7',
      'native_key' => 'tree_root_id',
      'filename' => 'modSystemSetting/b0d8903e7aeb3ef5bd0b6d3d7b8dd8b9.vehicle',
    ),
    434 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '96bc1e9f34406c2db07a294624b0b340',
      'native_key' => 'tvs_below_content',
      'filename' => 'modSystemSetting/a54bb0e7fac6b35d5a0fdfbe9d05b1e9.vehicle',
    ),
    435 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3d1ba4214ec2051738c17530405f4523',
      'native_key' => 'udperms_allowroot',
      'filename' => 'modSystemSetting/18150313419af7dff5b2a96db0ecd21a.vehicle',
    ),
    436 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0d2dc75d527a53b21b3eaf69943205db',
      'native_key' => 'unauthorized_page',
      'filename' => 'modSystemSetting/1b7606eaab24467413ceebec9fda77e4.vehicle',
    ),
    437 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2931be07481a22f56247247a79ce01f9',
      'native_key' => 'upload_files',
      'filename' => 'modSystemSetting/f44b4561552a23ffca75409570db916d.vehicle',
    ),
    438 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a9054d961218285cf49fb7585d03375d',
      'native_key' => 'upload_flash',
      'filename' => 'modSystemSetting/826e57af58c931ecd3896e2ceddee5c0.vehicle',
    ),
    439 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6155e7cf0829b3e0a7b26a5eb682200c',
      'native_key' => 'upload_images',
      'filename' => 'modSystemSetting/44f87a8a54ac3f2668faef5b04856ca9.vehicle',
    ),
    440 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4a21c0e7f662384849cc735cff6bdfa5',
      'native_key' => 'upload_maxsize',
      'filename' => 'modSystemSetting/9b6fc9b8430062e4c06632974e7074e8.vehicle',
    ),
    441 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2bf3ac3ac5d5f20b7e3391035edb9cc9',
      'native_key' => 'upload_media',
      'filename' => 'modSystemSetting/fda1644e34564c1714e3448c3412b57c.vehicle',
    ),
    442 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5dac1386d873b6c1c484db3c999495b5',
      'native_key' => 'use_alias_path',
      'filename' => 'modSystemSetting/84fb2df2407441939da01e406757bebe.vehicle',
    ),
    443 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7e11c4f71a6018d191c02541529d0f8b',
      'native_key' => 'use_browser',
      'filename' => 'modSystemSetting/6af49567bc4625410563e8459448b60b.vehicle',
    ),
    444 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '49838c1fc1bd5699bf6f7a96d77ef707',
      'native_key' => 'use_editor',
      'filename' => 'modSystemSetting/4aea4fcffbf14689786085f5dd9d9171.vehicle',
    ),
    445 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9ba9f112e0bcf1612c4725ed535cfa7f',
      'native_key' => 'use_multibyte',
      'filename' => 'modSystemSetting/ca741cc7f956a74dbbfbc38307f3e5f5.vehicle',
    ),
    446 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '75296b116a0c31b313ab36aa4001913e',
      'native_key' => 'use_weblink_target',
      'filename' => 'modSystemSetting/2324c3dcc44d8be9edc07f2d9b56490e.vehicle',
    ),
    447 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3f6706537b854e06e9957800a3937eca',
      'native_key' => 'webpwdreminder_message',
      'filename' => 'modSystemSetting/79f2f5b1737d2057746952a90723ca33.vehicle',
    ),
    448 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '49164f98b3401d8698c6f988fe00c349',
      'native_key' => 'websignupemail_message',
      'filename' => 'modSystemSetting/688107d733952ae202bac5acc82e3387.vehicle',
    ),
    449 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '80acefeea90bc0046caa887e14d69c18',
      'native_key' => 'welcome_screen',
      'filename' => 'modSystemSetting/abf40701bd2bb9b7b712aeff89bb1806.vehicle',
    ),
    450 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cd596e698b38d15d980767bbb7cb02e8',
      'native_key' => 'welcome_screen_url',
      'filename' => 'modSystemSetting/8b23c7103ed6fcd226202f388af09b45.vehicle',
    ),
    451 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f9c8e2f90fd90779edb8c54303533d5e',
      'native_key' => 'which_editor',
      'filename' => 'modSystemSetting/fbb50f6b23a54992f7098a9ac71fff40.vehicle',
    ),
    452 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '779e6f78566b65792c300c7cef3c5d0b',
      'native_key' => 'which_element_editor',
      'filename' => 'modSystemSetting/91ea4de634793ca788f466a16f6f6170.vehicle',
    ),
    453 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0468d6e8aae1040edfbca653ac678b62',
      'native_key' => 'xhtml_urls',
      'filename' => 'modSystemSetting/6563fbe8e4e3f8cb12db1a9689e1db8e.vehicle',
    ),
    454 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => '73cb3639a4afd55d1d7baaaf43d38fe9',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'allow_tags_in_post',
      ),
      'filename' => 'modContextSetting/6316090cf31538ce0c3e2bd58875702d.vehicle',
    ),
    455 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => '116d4b979d586c24c5a5517d83671782',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'modRequest.class',
      ),
      'filename' => 'modContextSetting/aa3fbc62c249343cc22d91c8bfd10c86.vehicle',
    ),
    456 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroup',
      'guid' => '1d63b8aed438808edbf061a322af6768',
      'native_key' => 1,
      'filename' => 'modUserGroup/6af82ee52b474ab6f1b4c74e76b44f38.vehicle',
    ),
    457 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboard',
      'guid' => '3aa5176a6e474964ab1b40160d77e825',
      'native_key' => 1,
      'filename' => 'modDashboard/42967c4c3e9ce862a69dc8d51e39ee5f.vehicle',
    ),
    458 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMediaSource',
      'guid' => '63007010e5aed9ff41aae0a0a6cc1f6c',
      'native_key' => 1,
      'filename' => 'modMediaSource/45586c17e12c6b83a3b569b28529d7b3.vehicle',
    ),
    459 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '640e03a4fa81f0f0e7094d84f78eaded',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/249fdaef7f2548dd196b5e55c3897492.vehicle',
    ),
    460 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'd29685225b7199151dcb84d17c60a218',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/4d1792c5cd1d35d7f48188b659672b40.vehicle',
    ),
    461 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'addd657b3ca86572ed87c25eabcf8b87',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/88ab228e714d51143d9490da0d97ae0d.vehicle',
    ),
    462 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'b2be7cdc999282db484cd82882b04c20',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/69cf95a59536002c59b072cb4a4179b5.vehicle',
    ),
    463 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'f69d29a19160f5dcbecfa86df976de3d',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/0d72771e3029b5a1efba6d6460905c06.vehicle',
    ),
    464 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => '43907b41ab88da0d08043d95e1ac0c47',
      'native_key' => 1,
      'filename' => 'modUserGroupRole/76ffd6ebdaa9d665f6c1912581285d06.vehicle',
    ),
    465 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => 'ec36464190e94f2a18f45eb14b7f9e4b',
      'native_key' => 2,
      'filename' => 'modUserGroupRole/62c5d9f1e053ef387b413ae6aacdf2e2.vehicle',
    ),
    466 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '0a2221353bb8c1171f1dfc0584249876',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/49b3fedebc89760c3a0db298f6c146bf.vehicle',
    ),
    467 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'e284e4ae8d9837f12ce5be33c2ccf1c4',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/d545b51f038670dab626b4fba00de724.vehicle',
    ),
    468 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '31fccd242a5af2f54ed8a62f60674988',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/32bd917d447fab2662e6340e913a5919.vehicle',
    ),
    469 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'bd57684df1bfa6745b704b7e826f8577',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/eb1831400c6423a0537e4aebd1e0995f.vehicle',
    ),
    470 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '5f714c9b54e994130ebcb1174dd555ff',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/311014f56c6a398b7f0e78fc903ff5ba.vehicle',
    ),
    471 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '3665c9798f38d977384aa4ac974b2e94',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/5a192c4e10ea240568059308ac1593a1.vehicle',
    ),
    472 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'e605a76af8fbadfe5610f844b6aa8bb6',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/ceaa38a2af433fb8c7bfc5a8a46ecd7c.vehicle',
    ),
    473 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '012a4827a0b3019c185757945a7841a9',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/6522a3d340e30f6554f23e1645ea55d0.vehicle',
    ),
    474 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '4aa9fd21431a0745258a713e6e1393ec',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/d504e1b561996a05ee0abab944a97f69.vehicle',
    ),
    475 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '63ab6e4e889dd3c959cfaa05846e5b5d',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/a0513b0291f104f8e6eb1ba1ca4a9aa5.vehicle',
    ),
    476 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'b189be625375858496653db4db7b5680',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/a89899ca80283adb86fff82fdcb50b34.vehicle',
    ),
    477 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '1d32c6e83052edd45be280cde112c51d',
      'native_key' => 1,
      'filename' => 'modAccessPolicy/534bbafcfd9014c5ae523ff74151cb06.vehicle',
    ),
    478 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '79199efdcf60d0a5c9c309d2593de204',
      'native_key' => 2,
      'filename' => 'modAccessPolicy/8a3450b7ac53b2a4909c37b9d4129b54.vehicle',
    ),
    479 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'de92e729c97ca947fdde4760725b6b6e',
      'native_key' => 3,
      'filename' => 'modAccessPolicy/765e70599f04ec4aea249cb129a445fa.vehicle',
    ),
    480 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '9d23b55af5f2fddeb2fcafd227ca61bd',
      'native_key' => 4,
      'filename' => 'modAccessPolicy/d896f3b75ffffa09cb03579da7d217b6.vehicle',
    ),
    481 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '38ced0359e1b8b54a7ed763877c1b5ab',
      'native_key' => 5,
      'filename' => 'modAccessPolicy/756105af457c69057ff4a8bd1659c096.vehicle',
    ),
    482 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'd3dd787ca925760235c55977ea878987',
      'native_key' => 6,
      'filename' => 'modAccessPolicy/183a4dfd57528ed4f7b26246d6dc44b2.vehicle',
    ),
    483 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '6d82ee4a31a164b830e5e0129553e26c',
      'native_key' => 7,
      'filename' => 'modAccessPolicy/adb5d5b088e7be5325cc22505bccedcd.vehicle',
    ),
    484 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '85b5ab709546caebfc8bacf1d895c540',
      'native_key' => 8,
      'filename' => 'modAccessPolicy/01baad636b8feba106b50257ed068b4b.vehicle',
    ),
    485 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '047583e359aee72403c08e2588e47adc',
      'native_key' => 9,
      'filename' => 'modAccessPolicy/0a4742b4160b7003e9cbbcb5ba60482d.vehicle',
    ),
    486 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'c132505229fbe3694b7ad64cb3b4d889',
      'native_key' => 10,
      'filename' => 'modAccessPolicy/790c731a8d27123908a5aa937abac486.vehicle',
    ),
    487 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '0e5aab46baa9510b01821a557632a1c8',
      'native_key' => 11,
      'filename' => 'modAccessPolicy/c1d6b94cacf50b1d5eb82532126a973e.vehicle',
    ),
    488 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => '2cddfe8121f5fde053a5f85305c8ff9b',
      'native_key' => 'web',
      'filename' => 'modContext/eac7a1a5915e96fd8bca7366ab65e2ae.vehicle',
    ),
    489 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => '3230cb0bade5a866b8e7fac63c10e97e',
      'native_key' => 'mgr',
      'filename' => 'modContext/eb50d53366293176f61cbe733e361698.vehicle',
    ),
    490 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'f560a002bb673bc0004d19773e8b6520',
      'native_key' => 'f560a002bb673bc0004d19773e8b6520',
      'filename' => 'xPDOFileVehicle/3614f91fda549983e6b5797a585326df.vehicle',
    ),
    491 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '7ed3b02243567a1d1c060f624ae76fa1',
      'native_key' => '7ed3b02243567a1d1c060f624ae76fa1',
      'filename' => 'xPDOFileVehicle/6625488e6be0fd756867ca7b8780c9e0.vehicle',
    ),
    492 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'c130fc5ca4dad4c8ced2d1729f942d53',
      'native_key' => 'c130fc5ca4dad4c8ced2d1729f942d53',
      'filename' => 'xPDOFileVehicle/e50c3f2cf8e6f0d38cbe53648efe350b.vehicle',
    ),
    493 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '1b4142673eec3e70be53fbffd4ba1c1c',
      'native_key' => '1b4142673eec3e70be53fbffd4ba1c1c',
      'filename' => 'xPDOFileVehicle/bf38bcb574dfaaea0d8be51686a3e854.vehicle',
    ),
    494 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '227bc926667029b784f530cdc2500126',
      'native_key' => '227bc926667029b784f530cdc2500126',
      'filename' => 'xPDOFileVehicle/f6419bbeb8182b7e4fbd029cc150189f.vehicle',
    ),
    495 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '0cc870139502daef57723d045e38f660',
      'native_key' => '0cc870139502daef57723d045e38f660',
      'filename' => 'xPDOFileVehicle/a54b1e762522fd2fd44a7cbd42a34336.vehicle',
    ),
    496 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '7afaf120c79c52f35b19c379aaebc242',
      'native_key' => '7afaf120c79c52f35b19c379aaebc242',
      'filename' => 'xPDOFileVehicle/619caabf6d6e80250dc1e63241b772ef.vehicle',
    ),
    497 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '1ceb72440f80b6966e2ff09ab5215c94',
      'native_key' => '1ceb72440f80b6966e2ff09ab5215c94',
      'filename' => 'xPDOFileVehicle/6cac2c920853c8c39a11098509dd855b.vehicle',
    ),
    498 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '14ddaa8a2b6c8e0fc1179279044ebf82',
      'native_key' => '14ddaa8a2b6c8e0fc1179279044ebf82',
      'filename' => 'xPDOFileVehicle/5f2c4995e5079f019dd3b66dcfb0c595.vehicle',
    ),
    499 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'd2d1d18eda990f59cdddb7405613e542',
      'native_key' => 'd2d1d18eda990f59cdddb7405613e542',
      'filename' => 'xPDOFileVehicle/f7c9816e858200e0c629bcdbdf0b8c63.vehicle',
    ),
    500 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '9819ffd335c4181bc42bf4ae93a2e1bc',
      'native_key' => '9819ffd335c4181bc42bf4ae93a2e1bc',
      'filename' => 'xPDOFileVehicle/30317c1758040aae844574931db1d3d8.vehicle',
    ),
  ),
);